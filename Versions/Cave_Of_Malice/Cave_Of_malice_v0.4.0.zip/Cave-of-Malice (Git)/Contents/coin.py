import pygame as pg
import os
import sys

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)


class Coin():
    def __init__(self, coinType, x, y, width, height, sourceImage):
        self.type = coinType
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        self.sourceImage = sourceImage
    
        self.image = pg.image.load(resource_path(self.sourceImage))
        self.image = pg.transform.scale(self.image, (self.width, self.height))

        self.mask = pg.mask.from_surface(self.image)
    

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
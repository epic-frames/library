import pygame as pg
import sys
import json
import random
import os
from enemy import Enemy
from text import Text
from player import Player
from world import World
# from coin import Coin

pg.init()

running = True

TILE_SIZE = 32
SCREEN_X = 1280
SCREEN_Y = 720
SCREEN = pg.display.set_mode((SCREEN_X, SCREEN_Y))
world = World("Assets/dirt.jpeg", "Assets/lava.jpeg", "Assets/diamond.png", TILE_SIZE)
pg.display.set_caption("Cave of Malice v0.3.0 - alpha")
clock = pg.time.Clock()

player = Player(100, 574, 28.5, 48, 5, 3, "Assets/player.png", None, 0.5, -6, 10, 3)

health_frames_source = []

for i in range(player.max_health):
    health_frames_source.append(i + 1)

health_frames = []

font = pg.font.Font(None, 36)
startupFont = pg.font.Font(None, 56)

speed_upgrade_cost = 3
speed_upgrade_level = 1
speed_upgrade_stage = 1
speed_stage_string = "Speed Level: " + str(speed_upgrade_stage)
jump_upgrade_cost = 3
jump_upgrade_level = 2
jump_upgrade_stage = 1
jump_stage_string = "Jump Level: " + str(jump_upgrade_stage)
luck_upgrade_cost = 3
luck_upgrade_level = 1
luck_upgrade_stage = 1
luck_percentage = 50
luck_upgrade_string = "Luck Level: " + str(luck_upgrade_stage)
health_upgrade_cost = 3
health_upgrade_level = 1
health_upgrade_stage = 1
health_upgrade_string = "Health Level: " + str(health_upgrade_stage)
wheel_cost = 1.5
wheel_level = 1

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)

try:
    background = pg.image.load(resource_path("Assets/bg.png"))
    background = pg.transform.scale(background, (SCREEN_X, SCREEN_Y))

    freeze_bg = pg.image.load(resource_path("Assets/freeze_bg.png"))
    freeze_bg = pg.transform.scale(freeze_bg, (SCREEN_X, SCREEN_Y))

    for frame in health_frames_source:
        health_frame = pg.image.load(resource_path(f"Assets/health-{str(player.max_health)}/health-{str(frame)}.png"))
        health_frame = pg.transform.scale(health_frame, (54, 10))
        touple = (health_frame, frame)
        health_frames.append(touple)

    menu_button = pg.image.load(resource_path("Assets/side-menu-button.png"))
    menu_button = pg.transform.scale(menu_button, (48, 108))

    menu_button_rect = menu_button.get_rect(topleft=(1232, 306))
    menu_button_mask = pg.mask.from_surface(menu_button)

    locked_img = pg.image.load(resource_path("Assets/Menu_Assets/locked.png"))
    locked_img = pg.transform.scale(locked_img, (100, 100))

except FileNotFoundError:
    print("Please make sure all files exist. Make sure the game is run within the Contents Folder. (FileNotFoundError)")
    pg.quit()
    sys.exit()

levelCount = 3

mode = ""

levels = [[] for _ in range(levelCount + 1)]

studioText = Text(None, None, "Epic Frame Studio", startupFont, (250, 250, 250), SCREEN_X, SCREEN_Y)
deathText = Text(None, None, "You died!", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
winText = Text(None, None, "You Win", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
coinText = Text(None, 45, f"Coins: {player.coins} (+ {player.temp_coins} when level cleared)", font, (0, 0, 0), SCREEN_X, SCREEN_Y)

for i in range(levelCount):
    levels[i + 1] = world.load_map("level" + str(i + 1) + ".txt")
    if levels[i + 1] == 0:
        pg.quit()
        sys.exit()

currentPage = "start_animation"
currentLevel = 1
level = levels[currentLevel]
coins_req = 0

speed_alert_active = False
jump_alert_active = False
luck_alert_active = False
health_alert_active = False
nothing_alert_active = False

FPS = 30

enemies = []

# Load json
try:
    with open(resource_path("enemies.json"), "r") as enemy_json_file:
        enemy_data = json.load(enemy_json_file)
    with open(resource_path("coins.json"), "r") as coins_json_file:
        coin_data = json.load(coins_json_file)
    with open(resource_path("upgrades.json"), "r") as upgrades_json_file:
        upgrade_data = json.load(upgrades_json_file)
except FileNotFoundError:
    print("JSON file not found. Quitting...")
    pg.quit()
    sys.exit()



def width():
    print("2 point perspective")


def start_animation():
    startTime = pg.time.get_ticks()
    duration = 4000
    frame, halfFrames = None, None
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_m:
                    return "game"

        SCREEN.fill((0, 0, 0))

        if frame or halfFrames != 0:
            frame, halfFrames = studioText.blink(SCREEN, duration / 1000 - 1.5, frame, halfFrames, 1500, pg.time.get_ticks())
        

        if pg.time.get_ticks() - startTime > duration:
            return "game"


        pg.display.update()
        clock.tick(FPS)

def game():
    global level, currentLevel, ifMenuActive, speed_upgrade_cost, jump_upgrade_cost, luck_upgrade_cost, wheel_cost, health_upgrade_cost, coins_req, speed_upgrade_stage, jump_upgrade_stage, luck_upgrade_stage, health_upgrade_stage, speed_alert_active, jump_alert_active, nothing_alert_active, luck_alert_active, health_alert_active, luck_percentage, health_frames
    world.load_tiles(level)
    # mode = "Jump"
    enemies, coins = world.spawn_assets(currentLevel, enemy_data, coin_data)
    ifMenuActive = False
    while True:
        if not ifMenuActive:
            for event in pg.event.get():
                if event.type == pg.KEYDOWN and event.key == pg.K_UP:
                    if player.jumps_available > 0:
                        player.jumping = True
                        player.yChange = player.jumpPower
                        player.on_ground = False
                        player.jumps_available -= 1
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_w:
                        currentLevel += 1
                        return "game"
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    local_x = mouse_x - menu_button_rect.x
                    local_y = mouse_y - menu_button_rect.y
                    if 0 <= local_x < menu_button_rect.width and 0 <= local_y < menu_button_rect.height:
                        if menu_button_mask.get_at((local_x, local_y)):
                            ifMenuActive = True
            
            if player.freezeFrame > 0:
                SCREEN.blit(freeze_bg, (0, 0))
            else:
                SCREEN.blit(background, (0, 0))

            if mode == "Jump":
                if player.on_ground:
                    player.jumping = True
                    player.yChange = player.jumpPower
                    player.on_ground = False

            # Move characters
            ifFreeze = False
            for enemy in enemies:
                if enemy.move():
                    ifFreeze = True

            if ifFreeze:
                ifDead, ifWin = player.move(world.tileList, freeze=True)
            else:
                ifDead, ifWin = player.move(world.tileList, freeze=False)
            

            # Detect collision
            if player.check_enemy_collision(enemies):
                ifDead = True
            player.check_coin_collision(coins)

            # Display character
            
            world.draw_map(SCREEN)
            coinText.update_text(f"Coins: {player.coins} (+ {player.temp_coins} once level cleared)")
            coinText.show(SCREEN)
            player.draw(SCREEN)
            for enemy in enemies:
                enemy.draw(SCREEN)
            for coin in coins:
                coin.draw(SCREEN)
            SCREEN.blit(menu_button, (1232, 306))
            
            if ifWin | ifDead:
                if ifWin:
                    if currentLevel < levelCount:
                        level, currentLevel = world.reset_level(levels, player, currentLevel)
                        return "game"
                    level, currentLevel = world.reset_level(levels, player, currentLevel, action="win_reset")
                    return "win_screen"
                else:
                    if player.health > 1:
                        level, currentLevel = world.reset_level(levels, player, currentLevel, action="die_reset")
                        return "game"
                    level, currentLevel = world.reset_level(levels, player, currentLevel, action="full_reset")
                    return "game_over"
            
            for frame in health_frames:
                if frame[1] == player.health:
                    SCREEN.blit(frame[0], (player.x - 13, player.y - 20))
            
            

            clock.tick(FPS)
            pg.display.update()
            
        else:

            
            SCREEN.fill((150, 150, 150))
            SCREEN.fill((200, 200, 200), (950, 0, SCREEN_X // 2, SCREEN_Y))

            

            upgrade_rects = []
            context = {
                "SCREEN_X": SCREEN_X,
                "SCREEN_Y": SCREEN_Y,
                "SCREEN": SCREEN,
                "font": font,
                "speed_upgrade_cost": speed_upgrade_cost,
                "jump_upgrade_cost": jump_upgrade_cost,
                "luck_upgrade_cost": luck_upgrade_cost,
                "health_upgrade_cost": health_upgrade_cost,
                "wheel_cost": wheel_cost,
                "speed_stage_string": "Speed Level: " + str(speed_upgrade_stage),
                "jump_stage_string": "Jump Level: " + str(jump_upgrade_stage),
                "luck_stage_string": "Luck Level: " + str(luck_upgrade_stage),
                "health_stage_string": "Health Level: " + str(health_upgrade_stage),
                "": ""
            }


            world.display_text(510, 75, f"Menu", startupFont, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, mode=1)

            for upgraded in upgrade_data:
                upgrade_rect, width, height, name = world.draw_upgrade(
                    upgraded["name"],
                    eval(upgraded["x"], {}, context),
                    eval(upgraded["y"], {}, context),
                    eval(upgraded["x2"], {}, context),
                    eval(upgraded["y2"], {}, context),
                    eval(upgraded["string"], {}, context),
                    eval(upgraded["font"], {}, context),
                    eval(upgraded["color"], {}, context),
                    eval(upgraded["screen_x"], {}, context),
                    eval(upgraded["screen_y"], {}, context),
                    eval(upgraded["screen"], {}, context),
                    int(upgraded["width"]),
                    int(upgraded["height"]),
                    upgraded["pic_path"],
                    upgraded["x3"],
                    upgraded["y3"],
                    context[upgraded["upgrade_stage"]],
                    int(upgraded["mode"])
                )


                upgrade_rects.append((upgrade_rect, width, height, name))
                upgrade_rect = None

            button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
            world.draw_button(460, 600, 100, 50, (255, 255, 255), button_text, SCREEN)


            for upgrade in upgrade_data:
                if upgrade["name"] == "Speed Upgrade":
                    if speed_upgrade_level > currentLevel or speed_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Jump Upgrade":
                    if jump_upgrade_level > currentLevel or jump_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Luck Upgrade":
                    if luck_upgrade_level > currentLevel or luck_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Health Upgrade":
                    if health_upgrade_level > currentLevel or health_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
            
            
            
            if speed_alert_active:
                world.alert(SCREEN, "Recived Reward: Speed Upgrade", font)
            elif jump_alert_active:
                world.alert(SCREEN, "Recived Reward: Jump Upgrade", font)
            elif luck_alert_active:
                world.alert(SCREEN, "Recived Reward: Luck Upgrade", font)
            elif health_alert_active:
                world.alert(SCREEN, "Recieved Reward: Health Upgrade", font)
            elif nothing_alert_active:
                world.alert(SCREEN, "Recived Reward: Nothing", font)
            
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    for rect in upgrade_rects:
                        local_x = mouse_x - rect[0].x
                        local_y = mouse_y - rect[0].y
                        if 0 <= local_x < rect[1] and 0 <= local_y < rect[2]:
                            if rect[3] == "Speed Upgrade":
                                if player.coins >= speed_upgrade_cost:
                                    if speed_upgrade_level <= currentLevel:
                                        if not speed_upgrade_stage >= 3:
                                            player.coins -= speed_upgrade_cost
                                            coins_req += speed_upgrade_cost
                                            player.speed += 2
                                            speed_upgrade_stage += 1
                                        else:
                                            print("This stat is maxed out. Heighest upgrade stage: 3")
                                    else:
                                        print("You have to reach a higher level to unlock this!")
                                else:
                                    print("Not enough coins!")
                                    
                            elif rect[3] == "Jump Upgrade":
                                if player.coins >= jump_upgrade_cost:
                                    if jump_upgrade_level <= currentLevel:
                                        if not jump_upgrade_stage >= 3:
                                            player.coins -= jump_upgrade_cost
                                            coins_req += jump_upgrade_cost
                                            player.jumpPower -= 2
                                            jump_upgrade_stage += 1
                                        else:
                                            print("This stat is maxed out. Heighest upgrade stage: 3")
                                    else:
                                        print("You have to reach a higher level to unlock this!")
                                else:
                                    print("Not enough coins!")
                            

                            elif rect[3] == "Luck Upgrade":
                                if player.coins >= luck_upgrade_cost:
                                    if luck_upgrade_level <= currentLevel:
                                        if not luck_upgrade_stage >= 3:
                                            player.coins -= luck_upgrade_cost
                                            coins_req += luck_upgrade_cost
                                            luck_percentage += 15
                                            luck_upgrade_stage += 1
                                        else:
                                            print("This stat is maxed out. Heighest upgrade stage: 3")
                                    else:
                                        print("You have to reach a higher level to unlock this!")
                                else:
                                    print("Not enough coins!")
                            
                            elif rect[3] == "Health Upgrade":
                                if player.coins >= health_upgrade_cost:
                                    if health_upgrade_level <= currentLevel:
                                        if not health_upgrade_stage >= 3:
                                            player.coins -= health_upgrade_cost
                                            coins_req += health_upgrade_cost
                                            player.max_health += 1
                                            health_upgrade_stage += 1
                                            health_frames = player.load_health_bar(health_frames_source, health_frames)
                                        else:
                                            print("This stat is maxed out. Heighest upgrade stage: 3")
                                    else:
                                        print("You have to reach a higher level to unlock this!")
                                else:
                                    print("Not enough coins!")

                            elif rect[3] == "Wheel":
                                if player.coins >=  wheel_cost:
                                    if wheel_level <= currentLevel:
                                        random_int = random.randint(1, 100)
                                        if random_int < luck_percentage:
                                            for _ in range(50):
                                                random_int = random.randint(1, 4)
                                                if random_int == 1 and not speed_upgrade_stage >= 3 and speed_upgrade_level <= currentLevel:
                                                    player.speed += 2
                                                    speed_upgrade_stage += 1
                                                    speed_alert_active = True
                                                    jump_alert_active = False
                                                    luck_alert_active = False
                                                    health_alert_active = False
                                                    nothing_alert_active = False
                                                    break
                                                elif random_int == 2 and not jump_upgrade_stage >= 3 and jump_upgrade_level <= currentLevel:
                                                    player.jumpPower -= 2
                                                    jump_upgrade_stage += 1
                                                    jump_alert_active = True
                                                    speed_alert_active = False
                                                    luck_alert_active = False
                                                    health_alert_active = False
                                                    nothing_alert_active = False
                                                    break
                                                elif random_int == 3 and not luck_upgrade_stage >= 3 and luck_upgrade_level <= currentLevel:
                                                    luck_percentage += 15
                                                    luck_upgrade_stage += 1
                                                    luck_alert_active = True
                                                    speed_alert_active = False
                                                    jump_alert_active = False
                                                    health_alert_active = False
                                                    nothing_alert_active = False
                                                    break
                                                elif random_int == 4 and not health_upgrade_stage >= 3 and health_upgrade_level <= currentLevel:
                                                    player.max_health += 1
                                                    health_upgrade_stage += 1
                                                    health_alert_active = True
                                                    luck_alert_active = False
                                                    speed_alert_active = False
                                                    jump_alert_active = False
                                                    nothing_alert_active = False
                                                    health_frames = player.load_health_bar(health_frames_source, health_frames)
                                                    break
                                        else:
                                            nothing_alert_active = True
                                            speed_alert_active = False
                                            jump_alert_active = False
                                            luck_alert_active = False
                                            health_alert_active = False
                                        player.coins -= wheel_cost
                                        coins_req += wheel_cost
                                    else:
                                        print("You have to reach a higher level to unlock this!")
                                else:
                                    print("Not enough coins!")


                    if 460 <= mouse_x < 660 and 600 <= mouse_y < 650:
                        ifMenuActive = False
                    
                    if SCREEN.get_width() // 2 - 50 <= mouse_x < SCREEN.get_width() // 2 + 50 and 125 <= mouse_y < 175 and (speed_alert_active or jump_alert_active or luck_alert_active or health_alert_active or nothing_alert_active):
                        speed_alert_active = False
                        jump_alert_active = False
                        luck_alert_active = False
                        health_alert_active = False
                        nothing_alert_active = False

            clock.tick(FPS)
            pg.display.update()

def game_over():
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 100
                    player.y = 572
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.temp_coins = 0
                    return "game"
        
        SCREEN.fill((255, 0, 0))

        deathText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        world.draw_button(590, 500, 100, 50, (194, 194, 194), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()


def win_screen():
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 100
                    player.y = 572
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.coins = 0
                    player.temp_coins = 0
                    return "game"
        
        SCREEN.fill((0, 255, 0))

        winText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        world.draw_button(590, 500, 100, 50, (194, 194, 194), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()


        
def main():
    global currentPage
    while True:
        if currentPage == "start_animation":
            currentPage = start_animation()
        elif currentPage == "game":
            currentPage = game()
        elif currentPage == "game_over":
            currentPage = game_over()
        elif currentPage == "win_screen":
            currentPage = win_screen()

if __name__ == "__main__":
    main()


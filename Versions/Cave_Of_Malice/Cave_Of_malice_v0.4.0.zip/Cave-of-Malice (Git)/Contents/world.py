import pygame as pg
from enemy import Enemy
from coin import Coin
import os
import sys

def resource_path(relative_path):
    """ Get absolute path to resource, works for dev and for PyInstaller """
    if hasattr(sys, '_MEIPASS'):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)


class World():
    def __init__(self, dirtImg, lavaImg, diamondImg, TILE_SIZE):
        self.dirtImgS = dirtImg
        self.dirtImg = pg.transform.scale(pg.image.load(resource_path(dirtImg)), (TILE_SIZE, TILE_SIZE))
        self.lavaImgS = lavaImg
        self.lavaImg = pg.transform.scale(pg.image.load(resource_path(lavaImg)), (TILE_SIZE, TILE_SIZE))
        self.diamondImgS = diamondImg
        self.diamondImg = pg.transform.scale(pg.image.load(resource_path(diamondImg)), (TILE_SIZE, TILE_SIZE))

        self.tileList = []
        self.TILE_SIZE = TILE_SIZE


    def load_map(self, mapName):
        try:
            with open(resource_path(mapName), "r") as file:
                level = [list(line.strip()) for line in file.readlines()]
                return level
        except FileNotFoundError:
            print("No level found")
            return 0
    

    def draw_map(self, SCREEN):
        for tile in self.tileList:
            SCREEN.blit(tile[0], tile[1])
    
    def get_image(self, tile, source):
        if source:
            if tile == "1":
                return self.dirtImgS
            elif tile == "2":
                return self.lavaImgS
            elif tile == "3":
                return self.diamondImgS
        else:
            if tile == "1":
                return self.dirtImg
            elif tile == "2":
                return self.lavaImg
            elif tile == "3":
                return self.diamondImg
            else:
                return self.dirtImg
    

    def load_tiles(self, level):
        self.tileList = []
        for row_index, row in enumerate(level):
            for col_index, tile in enumerate(row):
                if tile == "1" or tile == "2" or tile == "3":
                    image = self.get_image(tile, False)
                    img = pg.transform.scale(image, (self.TILE_SIZE, self.TILE_SIZE))
                    imgRect = pg.Rect(col_index * self.TILE_SIZE, row_index * self.TILE_SIZE, self.TILE_SIZE, self.TILE_SIZE)
                    tile = (img, imgRect, self.get_image(tile, True))
                    self.tileList.append(tile)
    


    def display_text(self, x: int, y: int, text: str, font, color: tuple, SCREEN_X: int, SCREEN_Y: int, SCREEN, mode=0):
        text_surface = font.render(text, True, color)
        text_width, text_height = text_surface.get_size()

        if mode == 1:
            x = x - (text_width / 2)
        
        if x is None:
            x = (SCREEN_X / 2) - (text_width / 2)
        if y is None:
            y = (SCREEN_Y / 2) - (text_height / 2)

        SCREEN.blit(text_surface, (x, y))

        return text_surface.get_size()

    def spawn_assets(self, level, enemy_data, coin_data):
        enemies = []
        coins = []
        data = enemy_data["levels"][str(level)]
        for enemyd in data:
            enemy = Enemy(enemyd["type"], enemyd["init_x"], enemyd["init_y"], enemyd["width"], enemyd["height"], enemyd["speed"], enemyd["health"], enemyd["src_img"], enemyd["dir"], enemyd["num1"], enemyd["num2"])
            enemies.append(enemy)
            enemy = None
        data = coin_data["levels"][str(level)]
        for coind in data:
            coin = Coin(coind["type"], coind["x"], coind["y"], coind["width"], coind["height"], coind["src_img"])
            coins.append(coin)
            coin = None
        
        return enemies, coins

    def draw_button(self, x, y, width, height, color, text, SCREEN):
        pg.draw.rect(SCREEN, color, (x, y, width, height))
        text_rect = text.get_rect(center=(x + width // 2, y + height // 2))
        SCREEN.blit(text, text_rect)
    

    def draw_upgrade(self, name: str, x: int, y: int, x2: int, y2: int, text: str, font, color: tuple, SCREEN_X: int, SCREEN_Y: int, SCREEN, width: int, height: int, pic_path: str, x3: str, y3: str, upgrade_stage: str, mode=0):
        upgrade = pg.image.load(resource_path(pic_path))
        upgrade = pg.transform.scale(upgrade, (width, height))
        upgrade_rect = upgrade.get_rect(topleft=(x2, y2))

        text_surface = font.render(text, True, color)
        text_width, text_height = text_surface.get_size()

        if mode == 1:
            x = x - (text_width / 2)
        
        if x is None:
            x = (SCREEN_X / 2) - (text_width / 2)
        if y is None:
            y = (SCREEN_Y / 2) - (text_height / 2)

        SCREEN.blit(text_surface, (x, y))
        SCREEN.blit(upgrade, (x2, y2))

        if x3 != "" and y3 != "" and upgrade_stage != "":
            text_surface = font.render(upgrade_stage, True, color)
            text_width, text_height = text_surface.get_size()
            if mode == 1:
                x3 = int(x3) - (text_width / 2)
            SCREEN.blit(text_surface, (x3, int(y3)))

        return upgrade_rect, width, height, name
    
    def alert(self, SCREEN, string: str, font):
        SCREEN.fill((100, 100, 100), ((SCREEN.get_width() // 2) - 250, 0, 500, 200))

        text_surface = font.render(string, True, (0, 0, 0))
        text_width, _ = text_surface.get_size()
        SCREEN.blit(text_surface, (SCREEN.get_width() // 2 - (text_width // 2), 20))
        button_text = pg.font.Font(None, 36).render("Close", True, (0, 0, 0))
        self.draw_button(SCREEN.get_width() // 2 - 50, 125, 100, 50, (255, 255, 255), button_text, SCREEN)
    
    def reset_level(self, levels, player, currentLevel, action="new_level"):
        global level
        if action == "new_level":
            currentLevel += 1
            player.health = 3
            level = levels[currentLevel]
            player.x = 100
            player.y = 574
            player.coins += player.temp_coins
            player.temp_coins = 0
        elif action == "win_reset":
            currentLevel = 1
            level = levels[currentLevel]
        elif action == "die_reset":
            player.health -= 1
            player.x = 100
            player.y = 574
            # player.coins += player.temp_coins
            player.temp_coins = 0
            level = levels[currentLevel]
        elif action == "full_reset":
            currentLevel = 1
            level = levels[currentLevel]
            player.x = 100
            player.y = 574
            player.coins = 0
            player.temp_coins = 0
            player.health = 3
        return level, currentLevel



import random

# Function to simulate 1000 tries with two upgrades (speed and jump) needing to be upgraded to stage 3
def simulate_upgrades_to_stage_3(num_trials=100000):
    total_costs = []
    i = 0
    
    for _ in range(num_trials):
        total_cost = 0
        upgrades = [0, 0]  # [speed, jump] upgrades
        spin_cost = 2.5
        spins = 0
        
        # Simulate until both upgrades reach level 3 (each needs 3 successful spins)
        while upgrades[0] < 3 or upgrades[1] < 3:
            spins += 1
            total_cost += spin_cost
            # spin_cost += 0.1  # Each spin costs 0.1 more than the last
            
            # 50/50 chance of getting an upgrade for each type
            for i in range(2):  # Two upgrades: speed and jump
                if random.random() < 0.5 and upgrades[i] < 3:
                    upgrades[i] += 1
            
        total_costs.append(total_cost)
        print(_)
    
    # Calculate the average total cost
    average_cost = sum(total_costs) / num_trials
    return average_cost, total_costs

# Run the simulation
average_cost, costs = simulate_upgrades_to_stage_3()

print(average_cost)

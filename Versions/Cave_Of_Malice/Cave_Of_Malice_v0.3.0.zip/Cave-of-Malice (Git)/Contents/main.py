import pygame as pg
import sys
import json
from enemy import Enemy
from text import Text
from player import Player
from world import World
from coin import Coin

pg.init()

running = True

TILE_SIZE = 32
SCREEN_X = 1280
SCREEN_Y = 720
SCREEN = pg.display.set_mode((SCREEN_X, SCREEN_Y))
world = World("Assets/dirt.jpeg", "Assets/lava.jpeg", "Assets/diamond.png", TILE_SIZE)
pg.display.set_caption("Cave of Malice v0.3.0 - alpha")
clock = pg.time.Clock()

player = Player(100, 574, 28.5, 48, 5, 2, "Assets/player.png", None, 0.5, -6, 10)

font = pg.font.Font(None, 36)
startupFont = pg.font.Font(None, 56)

speed_upgrade_cost = 2
speed_upgrade_level = 1
jump_upgrade_cost = 2
jump_upgrade_level = 2

try:
    background = pg.image.load("Assets/bg.png")
    background = pg.transform.scale(background, (SCREEN_X, SCREEN_Y))

    freeze_bg = pg.image.load("Assets/freeze_bg.png")
    freeze_bg = pg.transform.scale(freeze_bg, (SCREEN_X, SCREEN_Y))

    menu_button = pg.image.load("Assets/side-menu-button.png")
    menu_button = pg.transform.scale(menu_button, (48, 108))

    menu_button_rect = menu_button.get_rect(topleft=(1232, 306))
    menu_button_mask = pg.mask.from_surface(menu_button)

    jump_upgrade = pg.image.load("Assets/Menu_Assets/jump_upgrade.png")
    jump_upgrade = pg.transform.scale(jump_upgrade, (100, 100))
    jump_upgrade_rect = jump_upgrade.get_rect(topleft=((SCREEN_X * 3) // 4 - 50, 200))

    speed_upgrade = pg.image.load("Assets/Menu_Assets/speed_upgrade.png")
    speed_upgrade = pg.transform.scale(speed_upgrade, (100, 100))
    speed_upgrade_rect = speed_upgrade.get_rect(topleft=(SCREEN_X // 4 - 50, 200))

    coming_soon = pg.image.load("Assets/Menu_Assets/coming_soon.png")
    coming_soon = pg.transform.scale(coming_soon, (100, 100))
    coming_soon_rect = coming_soon.get_rect(topleft=(SCREEN_X // 4 - 50, 500))

    coming_soon2 = pg.image.load("Assets/Menu_Assets/coming_soon.png")
    coming_soon2 = pg.transform.scale(coming_soon2, (100, 100))
    coming_soon2_rect = coming_soon2.get_rect(topleft=((SCREEN_X * 3) // 4 - 50, 500))

except FileNotFoundError:
    print("Please make sure all files exist. (FileNotFoundError)")

levelCount = 3

mode = ""

levels = [[] for _ in range(levelCount + 1)]

studioText = Text(None, None, "Epic Frame Studio", startupFont, (250, 250, 250), SCREEN_X, SCREEN_Y)
deathText = Text(None, None, "You died!", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
winText = Text(None, None, "You Win", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
coinText = Text(None, 45, f"Coins: {player.coins + player.temp_coins}", font, (0, 0, 0), SCREEN_X, SCREEN_Y)

for i in range(levelCount):
    levels[i + 1] = world.load_map("level" + str(i + 1) + ".txt")
    if levels[i + 1] == 0:
        pg.quit()
        sys.exit()

currentPage = "start_animation"
currentLevel = 1
level = levels[currentLevel]
coins_req = 0

FPS = 30

enemies = []

# Load json
try:
    with open("enemies.json", "r") as enemy_json_file:
        enemy_data = json.load(enemy_json_file)
    with open("coins.json", "r") as coins_json_file:
        coin_data = json.load(coins_json_file)
except FileNotFoundError:
    print("JSON file not found. Quitting...")
    pg.quit()
    sys.exit()

def display_text(x: int, y: int, text: str, font: str, color: tuple, SCREEN_X: int, SCREEN_Y: int, mode=0):
    text_surface = font.render(text, True, color)
    text_width, text_height = text_surface.get_size()

    if mode == 1:
        x = x - (text_width / 2)
    
    if x is None:
        x = (SCREEN_X / 2) - (text_width / 2)
    if y is None:
        y = (SCREEN_Y / 2) - (text_height / 2)

    SCREEN.blit(text_surface, (x, y))

    return text_surface.get_size()

def spawn_assets(level):
    global enemies, coins
    enemies = []
    coins = []
    eflevel = enemy_data["levels"][str(level)]
    for enemyd in eflevel:
        enemy = Enemy(enemyd["type"], enemyd["init_x"], enemyd["init_y"], enemyd["width"], enemyd["height"], enemyd["speed"], enemyd["health"], enemyd["src_img"], enemyd["dir"], enemyd["num1"], enemyd["num2"])
        enemies.append(enemy)
        enemy = None
    eflevel = coin_data["levels"][str(level)]
    for coind in eflevel:
        coin = Coin(coind["type"], coind["x"], coind["y"], coind["width"], coind["height"], coind["src_img"])
        coins.append(coin)
        coin = None

def draw_button(x, y, width, height, color, text):
    pg.draw.rect(SCREEN, color, (x, y, width, height))
    text_rect = text.get_rect(center=(x + width // 2, y + height // 2))
    SCREEN.blit(text, text_rect)


def width():
    print("2 point perspective")


def start_animation():
    startTime = pg.time.get_ticks()
    duration = 4000
    frame, halfFrames = None, None
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_m:
                    return "game"

        SCREEN.fill((0, 0, 0))

        if frame or halfFrames != 0:
            frame, halfFrames = studioText.blink(SCREEN, duration / 1000 - 1.5, frame, halfFrames, 1500, pg.time.get_ticks())
        

        if pg.time.get_ticks() - startTime > duration:
            return "game"


        pg.display.update()
        clock.tick(FPS)

def game():
    global level, currentLevel, ifMenuActive, speed_upgrade_cost, jump_upgrade_cost, coins_req
    world.load_tiles(level)
    # mode = "Jump"
    spawn_assets(currentLevel)
    ifMenuActive = False
    while True:
        if not ifMenuActive:
            for event in pg.event.get():
                if event.type == pg.KEYDOWN and event.key == pg.K_UP:
                    if player.jumps_available > 0:
                        player.jumping = True
                        player.yChange = player.jumpPower
                        player.on_ground = False
                        player.jumps_available -= 1
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if event.key == pg.K_w:
                        currentLevel += 1
                        return "game"
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    local_x = mouse_x - menu_button_rect.x
                    local_y = mouse_y - menu_button_rect.y
                    if 0 <= local_x < menu_button_rect.width and 0 <= local_y < menu_button_rect.height:
                        if menu_button_mask.get_at((local_x, local_y)):
                            ifMenuActive = True
            
            if player.freezeFrame > 0:
                SCREEN.blit(freeze_bg, (0, 0))
            else:
                SCREEN.blit(background, (0, 0))

            if mode == "Jump":
                if player.on_ground:
                    player.jumping = True
                    player.yChange = player.jumpPower
                    player.on_ground = False

            # Move characters
            ifFreeze = False
            for enemy in enemies:
                if enemy.move():
                    ifFreeze = True

            if ifFreeze:
                ifDead, ifWin = player.move(world.tileList, freeze=True)
            else:
                ifDead, ifWin = player.move(world.tileList, freeze=False)
            

            # Detect collision
            if player.check_enemy_collision(enemies):
                ifDead = True
            player.check_coin_collision(coins)

            # Display character
            
            world.draw_map(SCREEN)
            coinText.update_text(f"Coins: {player.coins + player.temp_coins}")
            coinText.show(SCREEN)
            player.draw(SCREEN)
            for enemy in enemies:
                enemy.draw(SCREEN)
            for coin in coins:
                coin.draw(SCREEN)
            SCREEN.blit(menu_button, (1232, 306))
            
            if ifWin | ifDead:
                if ifWin:
                    if currentLevel < levelCount:
                        currentLevel += 1
                        level = levels[currentLevel]
                        player.x = 100
                        player.y = 574
                        player.coins = player.temp_coins
                        player.temp_coins = 0
                        return "game"
                    currentLevel = 1
                    level = levels[currentLevel]
                    return "win_screen"
                else: 
                    return "game_over"

            clock.tick(FPS)
            pg.display.update()
            
        else:
            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    local_x = mouse_x - speed_upgrade_rect.x
                    local_y = mouse_y - speed_upgrade_rect.y
                    if 0 <= local_x < 100 and 0 <= local_y < 100:
                        if player.coins >= speed_upgrade_cost and speed_upgrade_level <= currentLevel:
                            player.coins -= speed_upgrade_cost
                            coins_req += speed_upgrade_cost
                            print(coins_req)
                            speed_upgrade_cost += 0.4
                            speed_upgrade_cost = round(speed_upgrade_cost, 1)
                            player.speed += 0.5
                    
                    local_x = mouse_x - jump_upgrade_rect.x
                    local_y = mouse_y - jump_upgrade_rect.y
                    if 0 <= local_x < 100 and 0 <= local_y < 100:
                        if player.coins >=  jump_upgrade_cost and jump_upgrade_level <= currentLevel:
                            player.coins -= jump_upgrade_cost
                            coins_req += jump_upgrade_cost
                            print(coins_req)
                            jump_upgrade_cost += 0.4
                            jump_upgrade_cost = round(jump_upgrade_cost, 1)
                            print(jump_upgrade_cost)
                            player.jumpPower -= 0.5

                    if 590 <= mouse_x < 690 and 600 <= mouse_y < 650:
                        ifMenuActive = False

            
            SCREEN.fill((150, 150, 150))

            # player.coins = 100

            display_text(SCREEN_X // 2, 75, f"Menu", startupFont, (0, 0, 0), SCREEN_X, SCREEN_Y, mode=1)

            display_text(SCREEN_X // 4, 150, f"Upgrade your speed: {speed_upgrade_cost}$", font, (0, 0, 0), SCREEN_X, SCREEN_Y, mode=1)
            SCREEN.blit(speed_upgrade, (SCREEN_X // 4 - 50, 200))

            display_text((SCREEN_X * 3) // 4, 150, f"Upgrade your jump: {jump_upgrade_cost}$", font, (0, 0, 0), SCREEN_X, SCREEN_Y, mode=1)
            SCREEN.blit(jump_upgrade, ((SCREEN_X * 3) // 4 - 50, 200))

            display_text(SCREEN_X // 4, 450, f"Coming Soon", font, (0, 0, 0), SCREEN_X, SCREEN_Y, mode=1)
            SCREEN.blit(coming_soon, (SCREEN_X // 4 - 50, 500))

            display_text((SCREEN_X * 3) // 4, 450, f"Coming Soon", font, (0, 0, 0), SCREEN_X, SCREEN_Y, mode=1)
            SCREEN.blit(coming_soon2, ((SCREEN_X * 3) // 4 - 50, 500))

            button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
            draw_button(590, 600, 100, 50, (255, 255, 255), button_text)

            clock.tick(FPS)
            pg.display.update()

def game_over():
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 100
                    player.y = 572
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.temp_coins = 0
                    return "game"
        
        SCREEN.fill((255, 0, 0))

        deathText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        draw_button(590, 500, 100, 50, (194, 194, 194), button_text)

        clock.tick(FPS)
        pg.display.update()


def win_screen():
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 100
                    player.y = 572
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.coins = 0
                    player.temp_coins = 0
                    return "game"
        
        SCREEN.fill((0, 255, 0))

        winText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        draw_button(590, 500, 100, 50, (194, 194, 194), button_text)

        clock.tick(FPS)
        pg.display.update()


        
def main():
    global currentPage
    while True:
        if currentPage == "start_animation":
            currentPage = start_animation()
        elif currentPage == "game":
            currentPage = game()
        elif currentPage == "game_over":
            currentPage = game_over()
        elif currentPage == "win_screen":
            currentPage = win_screen()

if __name__ == "__main__":
    main()
test = "Hello"
test.varx = 1
test.vary = 2

print(test, test.vary)
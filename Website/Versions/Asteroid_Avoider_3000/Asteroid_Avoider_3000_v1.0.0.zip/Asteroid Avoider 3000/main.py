import pygame as pg
from random import randint
import sys



# Initialize pygame
pg.init()

# Set up screen dimensions and clock
screen_x = 800
screen_y = 600
screen = pg.display.set_mode((screen_x, screen_y))
pg.display.set_caption("Asteroids v1.0")
clock = pg.time.Clock()

font = pg.font.Font(None, 36)
main_font = pg.font.Font("font.ttf", 30)

# Load assets
asteroid_size = randint(75, 200)

asteroid_img = pg.image.load('asteroid.png')
asteroid_img_new = pg.transform.scale(asteroid_img, (asteroid_size, asteroid_size))
asteroid_mask = pg.mask.from_surface(asteroid_img_new)
asteroid_x = 0
asteroid_y = 100

sloweroid = pg.image.load('sloweroid.png')


fasteroid = pg.image.load('fasteroid.png')

speed = 10  # Asteroid falling speed
difficulty = 1

change_size = False
chance = None
save_speed = None
allow = True

asteroid_bg = pg.image.load("asteroid_background.png")
asteroid_bg_new = pg.transform.scale(asteroid_bg, (screen_x, screen_y))

points = 0

text_x = 10
text_y = 10

player_img = pg.image.load('player-new.png')
player_img_new = pg.transform.scale(player_img, (120, 120))
player_mask = pg.mask.from_surface(player_img_new)
player_x = 540
player_y = 480
player_x_change = 0

current_page = "start_menu"

gray = (150, 150, 150)

# Button Info
button1_x = 350
button1_y = 500
button1_width = 100
button1_height = 50

button2_x = 350
button2_y = 250
button2_width = 100
button2_height = 50

button3_x = 270
button3_y = 400
button3_width = 100
button3_height = 50

button4_x = 350
button4_y = 400
button4_width = 100
button4_height = 50

button5_x = 390
button5_y = 400
button5_width = 150
button5_height = 50

def asteroid(x, y):
    global asteroid_img_new, asteroid_size, change_size
    if change_size:
        roll_dice()
        asteroid_size = randint(75, 200)
        asteroid_img_new = pg.transform.scale(asteroid_img, (asteroid_size, asteroid_size))
        change_size = False
    screen.blit(asteroid_img_new, (x, y))

def player(x, y):
    screen.blit(player_img_new, (x, y))

def roll_dice():
    global speed, save_speed, chance, allow, points, asteroid_img_new, asteroid_img, asteroid_mask
    points += 0.25 * speed
    if chance == 1 or chance == 2:
        asteroid_img = pg.image.load('asteroid.png')
        asteroid_img_new = pg.transform.scale(asteroid_img, (asteroid_size, asteroid_size))
        asteroid_mask = pg.mask.from_surface(asteroid_img_new)
        speed = save_speed
    if allow:
        chance = randint(1, int(20 / int(difficulty)))
        print(chance, int(20 / int(difficulty)))
    if chance == 2:
        asteroid_img = sloweroid
        asteroid_img_new = pg.transform.scale(asteroid_img, (asteroid_size, asteroid_size))
        asteroid_mask = pg.mask.from_surface(asteroid_img_new)

        save_speed = speed
        speed = 2.5
    elif chance == 1:
        asteroid_img = fasteroid
        asteroid_img_new = pg.transform.scale(asteroid_img, (asteroid_size, asteroid_size))
        asteroid_mask = pg.mask.from_surface(asteroid_img_new)
        save_speed = speed
        speed = save_speed + 25
    else:
        if save_speed != None:
            speed = save_speed
            save_speed = None

def handle_events():
    global running, player_x_change, allow, chance, speed
    for event in pg.event.get():
        if event.type == pg.QUIT:
            print("Hello")
            pg.quit()
            sys.exit()
        if event.type == pg.KEYDOWN:
            if event.key == pg.K_LEFT:
                player_x_change = -10
            if event.key == pg.K_RIGHT:
                player_x_change = 10
            if event.key == pg.K_q:
                speed += 5
            if event.key == pg.K_ESCAPE:
                return "start_menu"
            if event.key == pg.K_o:
                allow = False
                chance = 1
        if event.type == pg.KEYUP:
            if event.key in (pg.K_LEFT, pg.K_RIGHT):
                player_x_change = 0

def text(text_x, text_y):
    points_surface = font.render(f"Points: {round(points)}", True, (255, 255, 255))
    screen.blit(points_surface, (text_x, text_y))

def reset_asteroid():
    global change_size, asteroid_x, asteroid_y
    if asteroid_y > screen_y:
        asteroid_y = -120
        asteroid_x = randint(0, screen_x - asteroid_size)
        change_size = True

def button(screen, x, y, width, height, color, text):
    pg.draw.rect(screen, color, (x, y, width, height))
    text_rect = text.get_rect(center=(x + width // 2, y + height // 2))
    screen.blit(text, text_rect)

def reset_game():
    global asteroid_x, asteroid_y, points, speed, player_x, player_x_change, change_size, chance, save_speed, allow
    asteroid_x = 0
    asteroid_y = 100
    speed = 10
    points = 0
    player_x = 540
    player_x_change = 0
    change_size = False
    chance = None
    save_speed = None
    allow = True



def start_menu():
    global difficulty
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_9:
                    return "main_page"
            if event.type == pg.MOUSEBUTTONDOWN:
                if button2_x <= mouse_x <= button2_x + button2_width and button2_y <= mouse_y <= button2_y + button2_height:
                    reset_game()
                    return "main_page"
                if button3_x <= mouse_x <= button3_x + button3_width and button3_y <= mouse_y <= button3_y + button3_height:
                    return "credit_page"                
                if button5_x <= mouse_x <= button5_x + button5_width and button5_y <= mouse_y <= button5_y + button5_height:
                    if difficulty == 1:
                        difficulty = 2
                    elif difficulty == 2:
                        difficulty = 3
                    elif difficulty == 3:
                        difficulty = 1
                    difficulty_text = font.render(f"Difficulty: " + str(difficulty), True, (0, 0, 0))
    
        screen.blit(asteroid_bg_new, (0, 0))

        game_name_text_surface = main_font.render(f"Asteroid Avoider 3000", True, (255, 255, 255))
        screen.blit(game_name_text_surface, (90, 70))

        start_text = font.render(f"Start", True, (0, 0, 0))
        button(screen, button2_x, button2_y, button2_width, button2_height, (194, 194, 194), start_text)

        credits_text = font.render(f"Credits", True, (0, 0, 0))
        button(screen, button3_x, button3_y, button3_width, button3_height, (194, 194, 194), credits_text)

        difficulty_text = font.render(f"Difficulty: " + str(difficulty), True, (0, 0, 0))
        button(screen, button5_x, button5_y, button5_width, button5_height, (194, 194, 194), difficulty_text)

        pg.display.update()

def credit_page():
    global back_text
    reset_game()
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_9:
                    return "main_page"
            if event.type == pg.MOUSEBUTTONDOWN:
                if button4_x <= mouse_x <= button4_x + button4_width and button4_y <= mouse_y <= button4_y + button4_height:
                    return "main_page"

    
        screen.fill(gray)

        andrey_text_surface = main_font.render(f"Game coder: Andrey", True, (0, 0, 0))
        screen.blit(andrey_text_surface, (90, 70))

        andrey_text_surface = main_font.render(f"Art designer: Carter", True, (0, 0, 0))
        screen.blit(andrey_text_surface, (90, 170))

        back_text = font.render(f"Back", True, (0, 0, 0))
        button(screen, button4_x, button4_y, button4_width, button4_height, (194, 194, 194), back_text)

        pg.display.update()

def main_page():
    global offset_x, offset_y, asteroid_y, player_x, speed, current_page
    while True:
        screen.fill((150, 150, 150))
    
        if handle_events() == "start_menu":
            return "start_menu"
        
        offset_x = asteroid_x - player_x
        offset_y = asteroid_y - player_y

        if player_mask.overlap(asteroid_mask, (offset_x, offset_y)):
            print("\n Final Score: " + str(round(points)) + "\n")
            return "end_page"
            

        # Update positions
        asteroid_y += speed
        player_x += player_x_change
        
        # Screen bounds for player
        if player_x < 0:
            player_x = 0
        if player_x > screen_x - 120:
            player_x = screen_x - 120

        reset_asteroid()

        # Draw objects
        asteroid(asteroid_x, asteroid_y)
        player(player_x, player_y)
        text(text_x, text_y)

        print(difficulty)

        pg.display.update()

        speed += 0.005 * difficulty
        clock.tick(30)

def end_page():
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_9:
                    return "start_menu"
            if event.type == pg.MOUSEBUTTONDOWN:
                if button1_x <= mouse_x <= button1_x + button1_width and button1_y <= mouse_y <= button1_y + button1_height:
                    return "start_menu"
    

        screen.fill((240, 10, 33))

        end_text_surface = font.render(f"You died! Be better!", True, (0, 0, 0))
        screen.blit(end_text_surface, (280, 100))


        points_surface = font.render(f"Points: {round(points)}", True, (0, 0, 0))
        screen.blit(points_surface, (350, 200))

        button_text = font.render(f"Restart", True, (0, 0, 0))
        button(screen, button1_x, button1_y, button1_width, button1_height, (255, 255, 255), button_text)

        

        pg.display.update()

def main():
    while True:
        current_page = "start_menu"
        if current_page == "start_menu":
            current_page = start_menu()
        if current_page == "main_page":
            current_page = main_page()
        if current_page == "end_page":
            current_page = end_page()
        if current_page == "credit_page":
            current_page = credit_page()


if __name__ == "__main__":
    main()

pg.quit()
import os, sys

def get_save_path():
    if sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support/Cave Of Malice")
    elif sys.platform == "win32":
        base = os.path.join(os.environ.get("APPDATA", os.path.expanduser("~")), "Cave Of Malice")
    else:
        base = os.path.expanduser("~/.cave_of_malice")
    os.makedirs(base, exist_ok=True)
    return os.path.join(base, "data.json")
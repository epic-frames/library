import pygame as pg
import os
import sys
from save_path import get_save_path

def resource_path(relative_path):
    base_path = None

    # PyInstaller (Windows/Linux builds)
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS

    # macOS .app bundle
    elif getattr(sys, "frozen", False):
        base_path = os.path.dirname(sys.executable)
        base_path = os.path.abspath(os.path.join(base_path, "..", "Resources"))

    else:
        # dev mode
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class Coin():
    def __init__(self, coinType, x, y, width, height, sourceImage):
        self.type = coinType
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        self.sourceImage = sourceImage
    
        self.image = pg.image.load(resource_path(self.sourceImage))
        self.image = pg.transform.scale(self.image, (self.width, self.height))

        self.mask = pg.mask.from_surface(self.image)
    

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
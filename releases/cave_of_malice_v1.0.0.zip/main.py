import pygame as pg
import time, os, json, sys, datetime, calendar, requests, random
# from enemy import Enemy
from text import Text
from player import Player
from world import World
# from helper_functions import Helper
# from coin import Coin 
from paths import resource_path, get_save_dir, get_assets_dir

pg.init()
pg.key.set_repeat(400, 40)

SAVE_DIR = get_save_dir()
ASSETS_DIR = get_assets_dir()

running = True

TILE_SIZE = 32
SCREEN_X = 1280
SCREEN_Y = 720
SCREEN = pg.display.set_mode((SCREEN_X, SCREEN_Y))
game_version = "v1.0.0"
testing_limitation = False
testing_seconds = 10
testing_frame = testing_seconds * 10
if_alpha = False
update_url = "https://epic-frames.github.io/library/updates.json"
database_url = "https://cave-of-malice-leaderboard-default-rtdb.europe-west1.firebasedatabase.app/scores.json"
# helper = Helper()
world = World("assets/dirt.jpg", "assets/lava.jpeg", "assets/diamond.png", "assets/invis_block.png", TILE_SIZE)
if if_alpha:
    pg.display.set_caption(f"Cave of Malice {game_version} - alpha")
else:
    pg.display.set_caption(f"Cave of Malice {game_version}")
clock = pg.time.Clock()
run_start_time = None
run_end_time = None

current_music = None

# Default slider state
dragging = False



skins_owned = []
skin_selected = []

def check_for_update(update_url: str, game_version: str):
    try:
        r = requests.get(update_url, timeout=3)
        data = r.json()

        latest = data["version"]

        if latest != game_version:
            return data
    except:
        pg.quit()
        sys.exit()

    return None


def save_data(data):
    with open(os.path.join(SAVE_DIR, "data.json"), "w") as file:
        json.dump(data, file, indent=4)

def post_data(name: str, new_time: float, url: str, date: str):
    try:
        # Get all scores
        response = requests.get(url)
        response.raise_for_status()
        scores = response.json() or {}

        existing_key = None
        existing_time = None

        # Find existing score for this name
        for key, value in scores.items():
            if value.get("name") == name:
                existing_key = key
                existing_time = value.get("time")
                break

        # If an existing score is better or equal, do nothing
        if existing_time is not None and new_time >= existing_time:
            return

        # Delete old score if there is one
        if existing_key is not None:
            delete_url = url.replace(".json", f"/{existing_key}.json")
            delete_response = requests.delete(delete_url)
            delete_response.raise_for_status()

        # Upload new score
        post_response = requests.post(url, json={
            "name": name,
            "time": new_time,
            "date": date
        })
        post_response.raise_for_status()

    except Exception as e:
        print(f"Failed to post score: {e}")

def load_asset(filename: str, size: tuple, format: str = ".png"):
    path = resource_path("assets/" + filename + format)
    asset = pg.image.load(path)
    asset = pg.transform.scale(asset, size)
    return asset

try:
    save_path = os.path.join(SAVE_DIR, "data.json")
    with open(save_path, "r") as file:
        data = json.load(file)
        if data["version"] != game_version:
            data["version"] = game_version
        for skin in data["skins"].values():
            if skin["owned"] == True:
                skins_owned.append(skin)
        for index, skin in enumerate(skins_owned):
            if skin["name"] == data["skin_selected"]:
                skin_selected = index
                break
except FileNotFoundError:
    os.makedirs(SAVE_DIR, exist_ok=True)
    with open(save_path, "w") as file:
        default_template = {
            "version": game_version,
            "skin_selected": "ninja",
            "skins": {
                "ninja": {
                    "name": "ninja",
                    "animation": True,
                    "animations": {
                        "idle_frames": 4,
                        "run_frames": 4,
                        "scale": 2.6666666666666665
                    },
                    "owned": True
                },
                "pirate": {
                    "name": "pirate",
                    "animation": True,
                    "animations": {
                        "idle_frames": 6,
                        "run_frames": 12,
                        "scale": 1.7
                    },
                    "owned": False
                },
                "soldier": {
                    "name": "soldier",
                    "animation": True,
                    "animations": {
                        "idle_frames": 1,
                        "run_frames": 4,
                        "scale": 3
                    },
                    "owned": True
                },
                "default": {
                    "name": "default",
                    "animation": False,
                    "owned": False
                }
            },
            "initial_params": {
                "initial_width": 32,
                "initial_height": 48
            },
            "codes": {
                "og-skin": {
                    "used": False,
                    "reward": {
                        "coins": 0,
                        "skin": "default",
                        "bg_img": ""
                    }
                },
                "fall-2026": {
                    "used": False,
                    "reward": {
                        "coins": 0,
                        "skin": "pirate",
                        "bg_img": ""
                    }
                }
            },
            "setting_params": {
                "speedrun_state": 0,
                "music_state": 50
            },
            "personal_best_time": 0
        }
        json.dump(default_template, file, indent=4)
    data = default_template
    with open(os.path.join(SAVE_DIR, "data.json"), "r") as file:
        data = json.load(file)
        for skin in data["skins"].values():
            if skin["owned"] == True:
                skins_owned.append(skin)
        for index, skin in enumerate(skins_owned):
            if skin["name"] == data["skin_selected"]:
                skin_selected = index
                break

player = Player(400, 608, 32, 48, 5, 3, resource_path(f"assets/skins/{skin['name']}.png"), None, 0.5, -6.25, 10, 3, 0, skins_owned, SAVE_DIR)
player.coins = 0

# Calculating slider position
slider_x = (260 * (data["setting_params"]["music_state"] / 100) + 220)

health_frames_source, health_frames = player.get_health_frames()

wheel_images = []

font = pg.font.Font(None, 36)
startupFont = pg.font.Font(None, 56)

player.default_ugrade_values()

alert_active = ""

def process_invisible_blocks():
    global invis_list
    
    
    i = 0
    while i < len(invis_list):
        block = invis_list[i]
        image, rect, source, timer = block
        
        
        timer -= 1
        
        if timer <= 0:
            
            if source == "assets/invis-frames/1.png":
                
                next_frame = pg.image.load(resource_path("assets/invis-frames/2.png"))
                next_frame = pg.transform.scale(next_frame, (32, 32))
                new_block = (next_frame, rect, "assets/invis-frames/2.png", 10)
                invis_list[i] = new_block
                
                
                for j, tile in enumerate(world.tileList):
                    if len(tile) >= 2 and tile[1] == rect:
                        world.tileList[j] = new_block
                        break
                
            elif source == "assets/invis-frames/2.png":
                
                next_frame = pg.image.load(resource_path("assets/invis-frames/3.png"))
                next_frame = pg.transform.scale(next_frame, (32, 32))
                new_block = (next_frame, rect, "assets/invis-frames/3.png", 10)
                invis_list[i] = new_block
                
                
                for j, tile in enumerate(world.tileList):
                    if len(tile) >= 2 and tile[1] == rect:
                        world.tileList[j] = new_block
                        break
                        
            elif source == "assets/invis-frames/3.png":
                
                invis_list.pop(i)
                
                
                tiles_to_remove = []
                for tile in world.tileList:
                    if len(tile) >= 2 and tile[1] == rect:
                        tiles_to_remove.append(tile)
                
                for tile in tiles_to_remove:
                    world.tileList.remove(tile)
                
                
                continue
                
        else:
            
            updated_block = (image, rect, source, timer)
            invis_list[i] = updated_block
            
            
            for j, tile in enumerate(world.tileList):
                if len(tile) >= 2 and tile[1] == rect:
                    world.tileList[j] = updated_block
                    break
        
        i += 1


try:
    background = load_asset("bg", (SCREEN_X, SCREEN_Y))
    menu_bg = load_asset("menu-bg", (SCREEN_X // 2, SCREEN_Y))
    cave_bg = load_asset("cave-bg", (SCREEN_X, SCREEN_Y))
    cave_bg_1 = load_asset("cave-bg-1", (SCREEN_X, SCREEN_Y))
    freeze_bg = load_asset("freeze-cave-bg", (SCREEN_X, SCREEN_Y))
    wheel_bg = load_asset("black", (SCREEN_X, SCREEN_Y))
    wheel_bg.set_alpha(200)

    menu_button = load_asset("side-menu-button", (48, 108))
    menu_button_rect = menu_button.get_rect(topleft=(1232, 306))
    menu_button_mask = pg.mask.from_surface(menu_button)

    locked_img = load_asset("menu-assets/locked", (100, 100))
    
    # wheel_img = load_asset("Wheels/wheel-0", (400, 400))
    wheel_arrow = load_asset("wheel_arrow", (50, 50))
    wheel_arrow_rect = wheel_arrow.get_rect(center=(SCREEN_X // 2, 150))

    for i in range(3):
        wheel_img = load_asset("wheels/wheel-" + str(i), (853, 480))
        wheel_images.append(wheel_img)
    
    coming_soon = load_asset("coming_soon", (95, 50))

except FileNotFoundError:
    pg.quit()
    sys.exit()

levelCount = 10

mode = ""

levels = [[] for _ in range(levelCount + 1)]

studioText = Text(None, None, "Epic Frame Studio", startupFont, (250, 250, 250), SCREEN_X, SCREEN_Y)
deathText = Text(None, None, "You died!", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
winText = Text(None, None, "You Win", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
coinTextBlack = Text(None, 45, f"Coins: {player.coins} (+ {player.temp_coins} when level cleared)", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
coinTextWhite = Text(None, 45, f"Coins: {player.coins} (+ {player.temp_coins} when level cleared)", font, (255, 255, 255), SCREEN_X, SCREEN_Y)

for i in range(levelCount):
    
    levels[i] = world.load_map(resource_path("assets/levels/level" + str(i) + ".txt"))
    print(levels)
    if levels[i] == 0:
        pg.quit()
        sys.exit()

currentPage = "start_animation"
currentLevel = 0
level = levels[currentLevel]
coins_req = 0
invis_list = []

world.to_break = False

future_speed_alert_active = False
future_dash_alert_active = False
future_luck_alert_active = False
future_health_alert_active = False
future_nothing_alert_active = False

FPS = 30

enemies = []

# Load json
try:
    with open(resource_path("data/enemies.json"), "r") as enemy_json_file:
        enemy_data = json.load(enemy_json_file)
    with open(resource_path("data/coins.json"), "r") as coins_json_file:
        coin_data = json.load(coins_json_file)
    with open(resource_path("data/upgrades.json"), "r") as upgrades_json_file:
        upgrade_data = json.load(upgrades_json_file)
except FileNotFoundError as e:
    alert_active = "JSON file not found. Quitting..."
    pg.quit()
    sys.exit()



def width():
    print("2 point perspective")


def start_animation():
    startTime = pg.time.get_ticks()
    duration = 4000
    frame, halfFrames = None, None
    while True:
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.KEYDOWN:
                if event.key == pg.K_m:
                    return "main_menu"

        SCREEN.fill((0, 0, 0))
        

        if frame or halfFrames != 0:
            frame, halfFrames = studioText.blink(SCREEN, duration / 1000 - 1.5, frame, halfFrames, 1500, pg.time.get_ticks())
        

        if pg.time.get_ticks() - startTime > duration:
            return "main_menu"


        pg.display.update()
        clock.tick(FPS)

def game():
    global current_music
    if current_music != "assets/music/game_music_1.mp3" or current_music != "assets/music/game_music_2.mp3":
        if random.randint(1, 2) == 1:
            pg.mixer.music.load(resource_path("assets/music/game_music_1.mp3"))
            current_music = "assets/music/game_music_1.mp3"
        else:
            pg.mixer.music.load(resource_path("assets/music/game_music_2.mp3"))
            current_music = "assets/music/game_music_2.mp3"
        
        pg.mixer.music.play(loops=-1, start=0.0)
        pg.mixer.music.set_volume((data["setting_params"]["music_state"] / 6) / 100)
    
    global level, currentLevel, ifMenuActive, coins_req, health_frames, future_speed_alert_active, future_health_alert_active, future_dash_alert_active, future_luck_alert_active, future_nothing_alert_active, wheel_spinning, alert_active, run_start_time, health_frames_source, health_frames, alert_active, testing_frame
    level = levels[currentLevel]
    world.load_tiles(level)
    enemies, coins = world.spawn_assets(currentLevel, enemy_data, coin_data)
    ifMenuActive = False
    if run_start_time == None and data["setting_params"]["speedrun_state"] == 1:
        run_start_time = time.time()
    player.state = "idle"
    player.state_frame = 0
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        if not ifMenuActive:
            for event in pg.event.get():
                if event.type == pg.KEYDOWN:
                    if (event.key == pg.K_w or event.key == pg.K_UP) and player.jumps_available > 0:
                            player.jumping = True
                            player.yChange = player.jumpPower
                            player.on_ground = False
                            player.jumps_available -= 1
                    elif event.key == pg.K_ESCAPE:
                        level = levels[currentLevel]
                        player.x = 400
                        player.y = 608
                        if hasattr(player, "hitbox"):
                            player.hitbox.x = player.x
                            player.hitbox.y = player.y
                        player.coins = 0
                        player.temp_coins = 0
                        player.health = player.max_health
                        for enemy in enemies:
                            enemy.x = 200
                            enemy.y = 597
                            enemy.direction = 1
                        run_start_time = None
                        return "main_menu"
                    elif event.key == pg.K_r:
                        currentLevel = 1
                        level = levels[currentLevel]
                        if hasattr(player, "hitbox"):
                            player.hitbox.x = player.x
                            player.hitbox.y = player.y
                        player.coins = 0
                        player.temp_coins = 0
                        player.health = player.max_health
                        for enemy in enemies:
                            enemy.x = 200
                            enemy.y = 597
                            enemy.direction = 1
                        player.x = 90
                        player.y = 608
                        run_start_time = None
                        return "game"
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.KEYDOWN:
                    if if_alpha and event.key == pg.K_v:
                        if currentLevel < levelCount - 1:
                            currentLevel += 1
                        return "game"
                    elif if_alpha and event.key == pg.K_c:
                        player.coins += 10
                    elif event.key == pg.K_e:
                        if player.dashing_cooldown == 0:
                            player.dash_direction = 1
                            player.dashing = 5
                    elif event.key == pg.K_q:
                        if player.dashing_cooldown == 0:
                            player.dash_direction = -1
                            player.dashing = 5
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    local_x = mouse_x - menu_button_rect.x
                    local_y = mouse_y - menu_button_rect.y
                    if 0 <= local_x < menu_button_rect.width and 0 <= local_y < menu_button_rect.height:
                        if menu_button_mask.get_at((local_x, local_y)):
                            ifMenuActive = True
            
            if player.freezeFrame > 0:
                SCREEN.blit(freeze_bg, (0, 0))
            elif currentLevel == 1:
                SCREEN.blit(background, (0, 0))
            elif currentLevel > 1 and currentLevel < 7:
                SCREEN.blit(cave_bg, (0, 0))
            elif currentLevel >= 7:
                SCREEN.blit(cave_bg_1, (0, 0))

            if mode == "Jump":
                if player.on_ground:
                    player.jumping = True
                    player.yChange = player.jumpPower
                    player.on_ground = False

            # Move characters
            ifFreeze = False
            for enemy in enemies:
                if enemy.move():
                    ifFreeze = True

            if ifFreeze:
                ifDead, ifWin = player.move(world.tileList, invis_list, data, freeze=True)
            else:
                ifDead, ifWin = player.move(world.tileList, invis_list, data)
            

            # Detect collision
            if player.check_enemy_collision(enemies):
                ifDead = True
            # Save data only after coin collection or upgrades, not every frame
            coins_collected = player.check_coin_collision(coins)
            if coins_collected:
                save_data(data)

            # Display character
            
            world.draw_map(SCREEN)
            if currentLevel > 1:
                coinTextWhite.update_text(f"Coins: {player.coins} (+ {player.temp_coins} once level cleared)")
                coinTextWhite.show(SCREEN)
            else:
                coinTextBlack.update_text(f"Coins: {player.coins} (+ {player.temp_coins} once level cleared)")
                coinTextBlack.show(SCREEN)
            player.draw(SCREEN)
            for enemy in enemies:
                enemy.draw(SCREEN)
            for coin in coins:
                coin.draw(SCREEN)
            SCREEN.blit(menu_button, (1232, 306))
            process_invisible_blocks()
            if ifWin or ifDead:
                if ifWin:
                    if currentLevel < levelCount - 1:
                        level, currentLevel = world.reset_level(levels, player, currentLevel)
                        return "game"
                    level, currentLevel = world.reset_level(levels, player, currentLevel, action="win_reset")
                    if data["setting_params"]["speedrun_state"] == 1:
                        run_time = time.time() - run_start_time
                        now = datetime.datetime.now()
                        if data["personal_best_time"] > run_time or data["personal_best_time"] == 0:
                            data["personal_best_time"] = round(run_time, 3)
                            
                            post_data(text_input(), round(run_time, 3), database_url, f"{now.day} {calendar.month_name[now.month]} {now.year} {now.hour}:{now.minute}")
                        save_data(data)
                    return "win_screen"
                elif ifDead:
                    if player.health > 1:
                        level, currentLevel = world.reset_level(levels, player, currentLevel, action="die_reset")
                        return "game"
                    
                    level, currentLevel = world.reset_level(levels, player, currentLevel, action="full_reset")
                    player.default_ugrade_values()
                    alert_active = ""
                    return "game_over"
            
            # Checks every health bar and loads the current one
            for frame in health_frames:
                if frame[1] == player.health:
                    SCREEN.blit(frame[0], (player.x + player.width // 2 - player.health_bar_width // 2, player.y - 20))
            
            # Dash icon rendering
            if player.dash_unlocked:
                dash_icon = pg.image.load(resource_path("assets/menu-assets/dash_upgrade.png"))
                dash_icon = pg.transform.scale(dash_icon, (50, 50))
                pg.draw.rect(SCREEN, (209, 159, 23), pg.Rect(1200, 650, 60, 60))
                SCREEN.blit(dash_icon, (1205, 655))
                overlap_height = (player.dashing_cooldown / 1.8) + 5
                pg.draw.rect(SCREEN, (209, 159, 23), pg.Rect(1200, 650, 60, overlap_height))
            
            # Creates speedrun timer
            if data["setting_params"]["speedrun_state"] == 1:
                run_time = time.time() - run_start_time
                world.display_text(50, 50, str(round(run_time, 1)), startupFont, (255, 255, 255), SCREEN_X, SCREEN_Y, SCREEN, center=False)
            
            clock.tick(FPS)
            pg.display.update()
            
        else:
            
            player.spin = False

            
            SCREEN.fill((150, 150, 150))
            SCREEN.fill((200, 200, 200), (950, 0, SCREEN_X // 2, SCREEN_Y))

            
            # player.coins = 100            

            upgrade_rects = []
            context = {
                "SCREEN_X": SCREEN_X,
                "SCREEN_Y": SCREEN_Y,
                "SCREEN": SCREEN,
                "font": font,
                "player": player,
                "speed_upgrade_cost": player.speed_upgrade_cost,
                "dash_upgrade_cost": player.dash_upgrade_cost,
                "luck_upgrade_cost": player.luck_upgrade_cost,
                "health_upgrade_cost": player.health_upgrade_cost,
                "wheel_cost": player.wheel_cost,
                "speed_stage_string": "Speed Level: " + str(player.speed_upgrade_stage),
                "dash_stage_string": "Dash Level: " + str(player.dash_upgrade_stage),
                "luck_stage_string": "Luck Level: " + str(player.luck_upgrade_stage),
                "health_stage_string": "Health Level: " + str(player.health_upgrade_stage),
                "": ""
            }


            world.display_text(510, 75, f"Menu", startupFont, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, center=True)

            for upgraded in upgrade_data:
                display_string = upgraded["string"]
                display_pic_path = upgraded["pic_path"]
                display_upgrade_stage = context[upgraded["upgrade_stage"]]
                display_x3 = upgraded["x3"]
                display_y3 = upgraded["y3"]
                display_font = upgraded["font"]

                if upgraded["name"] == "Wheel" and data["setting_params"]["speedrun_state"] == 1:
                    display_string = "f'Not available'"
                    display_pic_path = 'assets/menu-assets/locked.png'
                    display_upgrade_stage = "Enabled speedrun mode"
                    display_x3 = upgraded["x"]
                    display_y3 = int(upgraded["y"]) + 175
                    display_font = "pg.font.Font(None, 30)"

                if isinstance(display_font, str):
                    eval_globals = {"pg": pg, **context}
                    display_font_obj = eval(display_font, eval_globals, {})
                else:
                    display_font_obj = display_font

                upgrade_rect, width, height, name = world.draw_upgrade(
                    upgraded["name"],
                    eval(upgraded["x"], {}, context),
                    eval(upgraded["y"], {}, context),
                    eval(upgraded["x2"], {}, context),
                    eval(upgraded["y2"], {}, context),
                    eval(display_string, {}, context),
                    display_font_obj,
                    eval(upgraded["color"], {}, context),
                    eval(upgraded["screen_x"], {}, context),
                    eval(upgraded["screen_y"], {}, context),
                    eval(upgraded["screen"], {}, context),
                    int(upgraded["width"]),
                    int(upgraded["height"]),
                    display_pic_path,
                    display_x3,
                    display_y3,
                    display_upgrade_stage,
                    int(upgraded["mode"])
                )

                upgrade_rects.append((upgrade_rect, width, height, name))
                upgrade_rect = None


            button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
            world.draw_button(460, 600, 100, 50, (255, 255, 255), button_text, SCREEN)

            if data["setting_params"]["speedrun_state"] == 0:
                print("bad")

            for upgrade in upgrade_data:
                if upgrade["name"] == "Speed Upgrade":
                    if player.speed_upgrade_level > currentLevel or player.speed_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Dash Upgrade":
                    if player.dash_upgrade_level > currentLevel or player.dash_upgrade_stage >= 2:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Luck Upgrade":
                    if player.luck_upgrade_level > currentLevel or player.luck_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
                if upgrade["name"] == "Health Upgrade":
                    if player.health_upgrade_level > currentLevel or player.health_upgrade_stage >= 3:
                        SCREEN.blit(locked_img, (eval(upgrade["x2"]), eval(upgrade["y2"])))
            
            
            
            # if speed_alert_active:
            #     world.alert(SCREEN, "Recived Reward: Speed Upgrade", font)
            # elif jump_alert_active:
            #     world.alert(SCREEN, "Recived Reward: Jump Upgrade", font)
            # elif luck_alert_active:
            #     world.alert(SCREEN, "Recived Reward: Luck Upgrade", font)
            # elif health_alert_active:
            #     world.alert(SCREEN, "Recieved Reward: Health Upgrade", font)
            # elif nothing_alert_active:
            #     world.alert(SCREEN, "Recived Reward: Nothing", font)
            # elif 
            
            if alert_active != "":
                world.alert(SCREEN, alert_active, font)

            wheel_img = wheel_images[player.luck_upgrade_stage - 1]
            player.new_wheel = pg.transform.rotate(wheel_img, player.rotationDegree)
            wheel_rect = player.new_wheel.get_rect(center=(SCREEN_X // 2, SCREEN_Y // 2))
            
            if player.spinFrame > 0:
                wheel_spinning = True
                wheel_img = wheel_images[player.luck_upgrade_stage - 1]
                player.rotationDegree = (player.rotationDegree + player.spinFrame) % 360

                player.new_wheel = pg.transform.rotate(wheel_img, player.rotationDegree)
                wheel_rect = player.new_wheel.get_rect(center=(SCREEN_X // 2, SCREEN_Y // 2))

                if data["setting_params"]["speedrun_state"] == 0:
                    SCREEN.blit(wheel_bg, (0, 0))
                    SCREEN.blit(player.new_wheel, wheel_rect.topleft)
                    SCREEN.blit(wheel_arrow, wheel_arrow_rect.topleft)


            elif player.spinFrame == 0:
                alert_active = ""

                player.section = int(player.rotationDegree // 45)
                if player.section == 0:
                    if player.speed_upgrade_level <= currentLevel:
                        if not player.speed_upgrade_stage >= 3:
                            player.speed_upgrade_stage = player.upgrade("Speed", player.speed_upgrade_stage)
                            future_speed_alert_active = True
                        else:
                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                    else:
                        alert_active = "You have to reach a higher level to unlock this!"
                elif player.section == 2:
                    if player.health_upgrade_level <= currentLevel:
                        if not player.health_upgrade_stage >= 3:
                            player.health_upgrade_stage, health_frames_source, health_frames = player.upgrade("Health", player.health_upgrade_stage, health_frames_source, health_frames)
                            future_health_alert_active = True
                        else:
                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                    else:
                        alert_active = "You have to reach a higher level to unlock this!"
                elif player.section == 4:
                    if player.luck_upgrade_level <= currentLevel:
                        if not player.luck_upgrade_stage >= 3:
                            player.luck_upgrade_stage = player.upgrade("Luck", player.luck_upgrade_stage)
                            future_luck_alert_active = True
                        else:
                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                    else:
                        alert_active = "You have to reach a higher level to unlock this!"
                elif player.section == 6:
                    if player.dash_upgrade_level <= currentLevel:
                        if not player.dash_upgrade_stage >= 2:
                            player.dash_upgrade_stage = player.upgrade("Dash", player.dash_upgrade_stage)
                            future_dash_alert_active = True
                        else:
                            alert_active = "This stat is unlocked."
                    else:
                        alert_active = "You have to reach a higher level to unlock this!"
                elif player.luck > 0:
                    if player.section == 7:
                        if player.health_upgrade_level <= currentLevel:
                            if not player.health_upgrade_stage >= 3:
                                player.health_upgrade_stage, health_frames_source, health_frames = player.upgrade("Health", player.health_upgrade_stage, health_frames_source, health_frames)
                                future_health_alert_active = True
                            else:
                                alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                        else:
                            alert_active = "You have to reach a higher level to unlock this!"
                    elif player.luck == 2:
                        if player.section == 3:
                            if player.speed_upgrade_level <= currentLevel:
                                if not player.speed_upgrade_stage >= 3:
                                    player.speed_upgrade_stage = player.upgrade("Speed", player.speed_upgrade_stage)
                                    future_speed_alert_active = True
                                else:
                                    alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                            else:
                                alert_active = "You have to reach a higher level to unlock this!"
                    else:
                        future_nothing_alert_active = True
                else:
                    future_nothing_alert_active = True

                if data["setting_params"]["speedrun_state"] == 0:
                    SCREEN.blit(wheel_bg, (0, 0))
                    SCREEN.blit(player.new_wheel, wheel_rect.topleft)
                    SCREEN.blit(wheel_arrow, wheel_arrow_rect.topleft)

            elif player.spinFrame >= -10 and data["setting_params"]["speedrun_state"] == 0:
                SCREEN.blit(wheel_bg, (0, 0))
                SCREEN.blit(player.new_wheel, wheel_rect.topleft)
                SCREEN.blit(wheel_arrow, wheel_arrow_rect.topleft)
            
            else:
                wheel_spinning = False
                if future_speed_alert_active:
                    alert_active = "Recived Reward: Speed Upgrade"
                    future_speed_alert_active = False
                elif future_dash_alert_active:
                    alert_active = "Recived Reward: Dash Upgrade"
                    future_dash_alert_active = False
                elif future_health_alert_active:
                    alert_active = "Recived Reward: Health Upgrade"
                    future_health_alert_active = False
                elif future_luck_alert_active:
                    alert_active = "Recived Reward: Luck Upgrade"
                    future_luck_alert_active = False
                elif future_nothing_alert_active:
                    alert_active = "Recived Reward: Nothing"
                    future_nothing_alert_active = False
            


            for event in pg.event.get():
                if event.type == pg.QUIT:
                    pg.quit()
                    sys.exit()
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = event.pos
                    for rect in upgrade_rects:
                        local_x = mouse_x - rect[0].x
                        local_y = mouse_y - rect[0].y
                        if 0 <= local_x < rect[1] and 0 <= local_y < rect[2]:
                            alert_active = ""
                            if rect[3] == "Speed Upgrade":
                                if player.coins >= player.speed_upgrade_cost:
                                    if player.speed_upgrade_level <= currentLevel:
                                        if not player.speed_upgrade_stage >= 3:
                                            player.coins -= player.speed_upgrade_cost
                                            coins_req += player.speed_upgrade_cost
                                            player.speed_upgrade_stage = player.upgrade("Speed", player.speed_upgrade_stage)
                                            alert_active = "Upgrade Bought: Speed Upgrade"
                                        else:
                                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                                    else:
                                        alert_active = "You have to reach a higher level to unlock this!"
                                else:
                                    alert_active = "Not enough coins!"
                                    
                            elif rect[3] == "Dash Upgrade":
                                if player.coins >= player.dash_upgrade_cost:
                                    if player.dash_upgrade_level <= currentLevel:
                                        if not player.dash_upgrade_stage >= 2:
                                            player.coins -= player.dash_upgrade_cost
                                            coins_req += player.dash_upgrade_cost
                                            player.dash_upgrade_stage = player.upgrade("Dash", player.dash_upgrade_stage)
                                            alert_active = "Upgrade Bought: Dash Upgrade"
                                        else:
                                            alert_active = "This stat is unlocked."
                                    else:
                                        alert_active = "You have to reach a higher level to unlock this!"
                                else:
                                    alert_active = "Not enough coins!"
                            

                            elif rect[3] == "Luck Upgrade":
                                if player.coins >= player.luck_upgrade_cost:
                                    if player.luck_upgrade_level <= currentLevel:
                                        if not player.luck_upgrade_stage >= 3:
                                            player.coins -= player.luck_upgrade_cost
                                            coins_req += player.luck_upgrade_cost
                                            player.luck_upgrade_stage = player.upgrade("Luck", player.luck_upgrade_stage)
                                            alert_active = "Upgrade Bought: Luck Upgrade"
                                        else:
                                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                                    else:
                                        alert_active = "You have to reach a higher level to unlock this!"
                                else:
                                    alert_active = "Not enough coins!"
                            
                            elif rect[3] == "Health Upgrade":
                                if player.coins >= player.health_upgrade_cost:
                                    if player.health_upgrade_level <= currentLevel:
                                        if not player.health_upgrade_stage >= 3:
                                            player.coins -= player.health_upgrade_cost
                                            coins_req += player.health_upgrade_cost
                                            player.health_upgrade_stage, health_frames_source, health_frames = player.upgrade("Health", player.health_upgrade_stage, health_frames_source, health_frames)
                                            alert_active = "Upgrade Bought: Health Upgrade"
                                        else:
                                            alert_active = "This stat is maxed out. Heighest upgrade stage: 3"
                                    else:
                                        alert_active = "You have to reach a higher level to unlock this!"
                                else:
                                    alert_active = "Not enough coins!"


                            elif rect[3] == "Wheel" and data["setting_params"]["speedrun_state"] == 0:
                                if player.coins >= player.wheel_cost:
                                    if player.wheel_level <= currentLevel:
                                        if wheel_spinning == False:
                                            player.spin = True
                                        player.coins -= player.wheel_cost
                                        coins_req += player.wheel_cost
                                    else:
                                        alert_active = "You have to reach a higher level to unlock this!"
                                else:
                                    alert_active = "Not enough coins!"

                    if 460 <= mouse_x < 660 and 600 <= mouse_y < 650:
                        ifMenuActive = False
                    
                    if SCREEN.get_width() // 2 - 50 <= mouse_x < SCREEN.get_width() // 2 + 50 and 75 <= mouse_y < 125 and alert_active != "":
                        alert_active = ""
            
            player.render_wheel()

            clock.tick(FPS)
            pg.display.update()

def text_input():
    player_input = ""
    active = False
    alert_text = ""
    rect = pg.Rect(SCREEN_X // 2 - 200, SCREEN_Y // 2 - 75, 400, 50)
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 600 <= mouse_y <= 650:
                    return player_input
                if rect.collidepoint(event.pos) or alert_text != "":
                    active = True
                else:
                    active = False
                
                if alert_text != "":
                    if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 75 <= mouse_y <= 125:
                        alert_text = ""
            
            if event.type == pg.KEYDOWN and active:
                if event.key == pg.K_BACKSPACE:
                    player_input = player_input[:-1]

                elif event.key == pg.K_RETURN:
                    return player_input

                elif alert_text != "Input too long!":
                    player_input += event.unicode

        

        SCREEN.fill((150, 150, 150))
        text = Text(None, 50, f"Enter Name", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        text.show(SCREEN)
        
        if active:
            rect = pg.Rect(SCREEN_X // 2 - 205, SCREEN_Y // 2 - 80, 410, 60)
            if alert_text == "Input too long!":
                pg.draw.rect(SCREEN, (255, 0, 0), rect)
            else:
                pg.draw.rect(SCREEN, (0, 0, 255), rect)

        button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 600, 100, 50, (255, 255, 255), button_text, SCREEN)
        rect = pg.Rect(SCREEN_X // 2 - 200, SCREEN_Y // 2 - 75, 400, 50)
        pg.draw.rect(SCREEN, (255, 255, 255), rect)
        text_input = Text(450, -410, f"{player_input}", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        if text_input.get_width() > 380:
            alert_text = "Input too long!"
            player_input = player_input[:-1]
        text_input.show(SCREEN)

        if alert_text:
            world.alert(SCREEN, alert_text, font)

        clock.tick(FPS)
        pg.display.update()

def game_over():
    global run_start_time
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 90
                    player.y = 608
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.temp_coins = 0
                    run_start_time = None
                    return "game"
        
        SCREEN.fill((255, 0, 0))

        deathText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        world.draw_button(590, 500, 100, 50, (194, 194, 194), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()


def win_screen():
    global run_start_time
    while True:
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            if event.type == pg.MOUSEBUTTONDOWN:
                if 590 <= mouse_x <= 690 and 500 <= mouse_y <= 550:
                    player.x = 90
                    player.y = 608
                    for enemy in enemies:
                        enemy.x = 200
                        enemy.y = 597
                        enemy.direction = 1
                    player.coins = 0
                    player.temp_coins = 0
                    player.health = player.max_health
                    run_start_time = None
                    return "game"
        
        SCREEN.fill((0, 255, 0))

        winText.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Restart", True, (0, 0, 0))
        world.draw_button(590, 500, 100, 50, (194, 194, 194), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()


def main_menu():
    global currentLevel, run_start_time, enemies, coins, invis_list, current_music, testing_frame
    currentLevel = 0
    level = levels[currentLevel]
    world.load_tiles(level)
    enemies = []
    coins = []
    invis_list = []
    
    if not pg.mixer.music.get_busy() or current_music != "assets/music/menu_music.mp3":
        pg.mixer.music.load(resource_path("assets/music/menu_music.mp3"))
        pg.mixer.music.play(loops=-1, start=0.0)
        pg.mixer.music.set_volume((data["setting_params"]["music_state"] / 4) / 100)
        current_music = "assets/music/menu_music.mp3"
    alert_text = ""
    pg.event.clear()
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.KEYDOWN and (event.key == pg.K_w or event.key == pg.K_UP):
                    if player.jumps_available > 0:
                        player.jumping = True
                        player.yChange = player.jumpPower
                        player.on_ground = False
                        player.jumps_available -= 1
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if ((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5) <= mouse_x <= (((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5)) + (SCREEN_X // 4) - (2 * (SCREEN_X // 20)) and SCREEN_Y // 5 <= mouse_y <= SCREEN_Y // 5 + 50:
                    currentLevel += 1
                    player.x = 90
                    player.y = 608
                    run_start_time = None
                    return "game"
                elif ((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5) <= mouse_x <= (((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5)) + (SCREEN_X // 4) - (2 * (SCREEN_X // 20)) and SCREEN_Y // 5 <= mouse_y <= (SCREEN_Y // 5) * 2 + 50:
                    return "settings"
                elif ((SCREEN_X // 4) // 5) <= mouse_x <= (((SCREEN_X // 4) // 5)) + (SCREEN_X // 4) - (2 * (SCREEN_X // 20)) and SCREEN_Y // 5 <= mouse_y <= SCREEN_Y // 5 + 50:
                    return "skins"
                elif ((SCREEN_X // 4) // 5) <= mouse_x <= (((SCREEN_X // 4) // 5)) + (SCREEN_X // 4) - (2 * (SCREEN_X // 20)) and (SCREEN_Y // 5) * 2 <= mouse_y <= (SCREEN_Y // 5) * 2 + 50:
                    return "codes"
                if alert_text != "":
                        if SCREEN_X // 2 + 530 <= mouse_x <= SCREEN_X // 2 + 610 and 65 <= mouse_y <= 105:
                            alert_text = ""
        
        # SCREEN.fill((150, 150, 150))
        SCREEN.blit(menu_bg, (SCREEN_X // 4, 0))
        pg.draw.rect(SCREEN, (150, 150, 150), (0, 0, SCREEN_X // 4, SCREEN_Y))
        pg.draw.rect(SCREEN, (150, 150, 150), ((SCREEN_X // 4) * 3, 0, SCREEN_X // 3, SCREEN_Y))

        local_text = font.render("Start Game", None, (0, 0, 0))
        world.draw_button(((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5), SCREEN_Y // 5, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50, (255, 255, 255), local_text, SCREEN)

        local_text = font.render("Settings", None, (0, 0, 0))
        world.draw_button(((SCREEN_X // 4) * 3) + ((SCREEN_X // 4) // 5), (SCREEN_Y // 5) * 2, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50, (100, 100, 100), local_text, SCREEN)

        local_text = font.render("Skins", None, (0, 0, 0))
        world.draw_button(((SCREEN_X // 4) // 5), SCREEN_Y // 5, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50, (100, 100, 100), local_text, SCREEN)

        local_text = font.render("Codes", None, (0, 0, 0))
        world.draw_button(((SCREEN_X // 4) // 5), (SCREEN_Y // 5) * 2, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50, (100, 100, 100), local_text, SCREEN)
        
        local_text = font.render("Coming Soon", None, (0, 0, 0))
        world.draw_button(((SCREEN_X // 4) // 5), (SCREEN_Y // 5) * 3, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50, (100, 100, 100), local_text, SCREEN)
        rect = pg.Rect(((SCREEN_X // 4) // 5), (SCREEN_Y // 5) * 3, (SCREEN_X // 4) - (2 * (SCREEN_X // 20)), 50)
        pg.draw.rect(SCREEN, (255, 255, 255), rect)
        SCREEN.blit(coming_soon, (((SCREEN_X // 4) // 5) + (((SCREEN_X / 4) - (2 * (SCREEN_X / 20))) / 2) - 47.5, (SCREEN_Y // 5) * 3))

        player.move(world.tileList, invis_list, data)
        world.draw_map(SCREEN)
        player.draw(SCREEN)

        if alert_text != "":
            world.alert(SCREEN, alert_text, font, corner=True)


        clock.tick(FPS)
        pg.display.update()


def skins():
    global skin_selected, data, testing_frame
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        mouse_x, mouse_y = pg.mouse.get_pos()
        legacy_index = False
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 600 <= mouse_y <= 650:
                    return "main_menu"
                skin_selected, data = player.change_player_skin(SCREEN_X, (mouse_x, mouse_y), skins_owned, skin_selected, mode="skin_selected")
                
        
        legacy_index = player.change_player_skin(SCREEN_X, (mouse_x, mouse_y), skins_owned, skin_selected, mode="legacy_index")
        SCREEN.fill((150, 150, 150))
        text = Text(None, 50, f"Skins", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        text.show(SCREEN)

        

        for i in range(2):
            for j in range(6):
                if legacy_index == i * 6 + j:
                    if i * 6 + j == skin_selected:
                        pg.draw.rect(SCREEN, (255, 255, 255), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 85, 140 + i * 210, 170, 170), border_radius=30)
                        pg.draw.rect(SCREEN, (243, 182, 5), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 75, 140 + i * 210 + 10, 150, 150), border_radius=20)
                    else:
                        pg.draw.rect(SCREEN, (60, 60, 60), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 85, 140 + i * 210, 170, 170), border_radius=30)
                        pg.draw.rect(SCREEN, (243, 182, 5), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 75, 140 + i * 210 + 10, 150, 150), border_radius=20)
                else:
                    if i * 6 + j == skin_selected:
                        pg.draw.rect(SCREEN, (255, 255, 255), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 85, 140 + i * 210, 170, 170), border_radius=30)
                        pg.draw.rect(SCREEN, (100, 100, 100), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 75, 140 + i * 210 + 10, 150, 150), border_radius=20)
                    else:
                        pg.draw.rect(SCREEN, (60, 60, 60), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 85, 140 + i * 210, 170, 170), border_radius=30)
                        pg.draw.rect(SCREEN, (100, 100, 100), ((SCREEN_X // 6) * j + SCREEN_X // 12 - 75, 140 + i * 210 + 10, 150, 150), border_radius=20)
        
        for skin in skins_owned:
            skin_img = pg.image.load(resource_path(f"assets/skins/{skin['name']}.png"))
            width, height = skin_img.get_size()
            max = 140
            scale_w = max / width
            scale_h = max / height
            scale = min(scale_w, scale_h)
            new_width = int(width * scale)
            new_height = int(height * scale)
            skin_img = pg.transform.scale(skin_img, (new_width, new_height))



            SCREEN.blit(skin_img, ((SCREEN_X // 6) * skins_owned.index(skin) + SCREEN_X // 12 - (new_width // 2), 140 + (skins_owned.index(skin) // 6) * 210 + 10 + 75 - (new_height // 2)))

        button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 600, 100, 50, (255, 255, 255), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()

def codes():
    global skin_selected, testing_frame
    player_input = ""
    active = False
    alert_text = ""
    rect = pg.Rect(SCREEN_X // 2 - 200, SCREEN_Y // 2 - 75, 400, 50)
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        mouse_x, mouse_y = pg.mouse.get_pos()
        for event in pg.event.get():
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 600 <= mouse_y <= 650:
                    return "main_menu"
                if rect.collidepoint(event.pos) or alert_text != "":
                    active = True
                else:
                    active = False
                
                if alert_text != "":
                    if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 75 <= mouse_y <= 125:
                        alert_text = ""
            
            if event.type == pg.KEYDOWN and active:
                if event.key == pg.K_BACKSPACE:
                    player_input = player_input[:-1]

                elif event.key == pg.K_RETURN:
                    alert_text, valid = world.check_code(player_input, SCREEN, font, SAVE_DIR)
                    if valid:
                        reward = data["codes"][player_input]["reward"]
                        if data["codes"][player_input]["used"] == False:
                            data["codes"][player_input]["used"] = True
                            if reward["coins"] > 0:
                                player.coins += reward["coins"]
                                alert_text = f"Code matched. Reward: Coins ({reward["coins"]})"
                            elif reward["skin"] != "":
                                data["skins"][reward["skin"]]["owned"] = True
                                alert_text = f"Code matched. Reward: Skin ({reward["skin"]})"
                                skins_owned.append(data["skins"][reward["skin"]])
                            elif reward["bg_img"] != "":
                                # Add background reward system
                                alert_text = f"Code matched. Reward: Background ({reward["bg_img"]})"
                    save_data(data)

                elif alert_text != "Input too long!":
                    player_input += event.unicode

        

        SCREEN.fill((150, 150, 150))
        text = Text(None, 50, f"Codes", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        text.show(SCREEN)
        
        if active:
            rect = pg.Rect(SCREEN_X // 2 - 205, SCREEN_Y // 2 - 80, 410, 60)
            if alert_text == "Input too long!":
                pg.draw.rect(SCREEN, (255, 0, 0), rect)
            else:
                pg.draw.rect(SCREEN, (0, 0, 255), rect)

        button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 600, 100, 50, (255, 255, 255), button_text, SCREEN)
        rect = pg.Rect(SCREEN_X // 2 - 200, SCREEN_Y // 2 - 75, 400, 50)
        pg.draw.rect(SCREEN, (255, 255, 255), rect)
        text_input = Text(450, -410, f"{player_input}", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        if text_input.get_width() > 380:
            alert_text = "Input too long!"
            player_input = player_input[:-1]
        text_input.show(SCREEN)

        if alert_text:
            world.alert(SCREEN, alert_text, font)

        clock.tick(FPS)
        pg.display.update()

def settings():
    global data, slider_x, testing_frame
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        mouse_x, mouse_y = pg.mouse.get_pos()
        events = pg.event.get()
        for event in events:
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 600 <= mouse_y <= 650:
                    return "main_menu"
                elif SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 350 <= mouse_y <= 400:
                    return "credits"

        
        SCREEN.fill((150, 150, 150))
        text = Text(None, 50, f"Settings", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        text.show(SCREEN)


        button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 600, 100, 50, (255, 255, 255), button_text, SCREEN)

        temp_font = pg.font.Font(None, 30)

        snapshot_data = json.loads(json.dumps(data))
        data["setting_params"]["speedrun_state"] = world.create_setting(160, SCREEN, SCREEN_X, SCREEN_Y, "Speedrunning Mode", temp_font, events, data["setting_params"]["speedrun_state"], type="checkmark")
        data["setting_params"]["music_state"], slider_x = world.create_setting(240, SCREEN, SCREEN_X, SCREEN_Y, "Music Volume", temp_font, events, data["setting_params"]["music_state"], type="slider", slider_x=slider_x)
        if data != snapshot_data:
            save_data(data)
        pg.mixer.music.set_volume((data["setting_params"]["music_state"] / 4) / 100)

        button_text = pg.font.Font(None, 36).render(f"Credits", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 350, 100, 50, (100, 100, 100), button_text, SCREEN)

        clock.tick(FPS)
        pg.display.update()

def credits():
    global testing_frame
    while True:
        if testing_limitation:
            testing_frame -= 1
            if testing_frame == 0:
                pg.quit()
                sys.exit()
        mouse_x, mouse_y = pg.mouse.get_pos()
        events = pg.event.get()
        for event in events:
            if event.type == pg.QUIT:
                pg.quit()
                sys.exit()
            
            if event.type == pg.MOUSEBUTTONDOWN:
                if SCREEN_X // 2 - 50 <= mouse_x <= SCREEN_X // 2 + 50 and 600 <= mouse_y <= 650:
                    return "settings"

        
        SCREEN.fill((150, 150, 150))
        text = Text(None, 50, f"Credits", font, (0, 0, 0), SCREEN_X, SCREEN_Y)
        text.show(SCREEN)

        button_text = pg.font.Font(None, 36).render(f"Exit", True, (0, 0, 0))
        world.draw_button(SCREEN_X // 2 - 50, 600, 100, 50, (255, 255, 255), button_text, SCREEN)

        world.display_text(None, 150, "Assets from (opengameart.org):", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 185, "Spider Asset - @ethanf30games", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 215, "Ninja Asset - @morgan3d, @dezrasdragons", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 245, "Dirt Asset - @ForKotLow", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 270, "Lava Asset - pinterest.com", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 320, "Cave Background Asset - SlashDashGames Studio (itch.io)", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 370, "Music (Youtube Music Library):", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)
        world.display_text(None, 440, "Spaghetti Eastern - John Patitucci", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN, True)

        clock.tick(FPS)
        pg.display.update()


pages = {
    "start_animation": start_animation,
    "main_menu": main_menu,
    "game": game,
    "game_over": game_over,
    "win_screen": win_screen,
    "skins": skins,
    "codes": codes,
    "settings": settings,
    "credits": credits
}
        
def main():
    global currentPage
    while True:
        if currentPage in pages:
            nextPage = pages[currentPage]()
            currentPage = nextPage
        else:
            pg.quit()
            sys.exit()

if __name__ == "__main__":
    main()

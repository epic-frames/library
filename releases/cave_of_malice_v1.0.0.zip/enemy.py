import pygame as pg
import random
import os
import sys
from save_path import get_save_path
# and use get_save_path() wherever data.json is opened

def resource_path(relative_path):
    base_path = None

    # PyInstaller (Windows/Linux builds)
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS

    # macOS .app bundle
    elif getattr(sys, "frozen", False):
        base_path = os.path.dirname(sys.executable)
        base_path = os.path.abspath(os.path.join(base_path, "..", "Resources"))

    else:
        # dev mode
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class Enemy():
    def __init__(self, enemyType, x, y, width, height, speed, health, sourceImage, direction, num1, num2, power):
        self.type = enemyType
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.speed = speed
        self.health = health

        if self.type == "Spider":
            self.x1 = num1
            self.x2 = num2
        elif self.type == "Lava Bubbles":
            self.y1 = num1
            self.y2 = num2
        elif self.type == "Watcher":
            self.x1 = num1
            self.x2 = num2

        self.direction = direction

        self.sourceImage = sourceImage
    
        self.image = pg.image.load(resource_path(self.sourceImage))
        self.image = pg.transform.scale(self.image, (self.width, self.height))

        self.mask = pg.mask.from_surface(self.image)

        self.yChange = 0
        self.bubble_wait = -1
        self.power = power


    def move(self):
        if self.type == "Spider":
            self.x += self.speed * self.direction
            if self.x <= self.x1:
                self.direction = 1
            elif self.x >= self.x2:
                self.direction = -1
        elif self.type == "Lava Bubbles":
            if self.bubble_wait == -1:
                self.yChange += 0.15
                self.y += self.yChange
            if self.y >= self.y2:
                if self.bubble_wait == -1:
                    self.bubble_wait = 15
                elif self.bubble_wait > 0:
                    self.bubble_wait -= 1
                else:
                    self.yChange = -self.power
                    self.bubble_wait -= 1 
                # self.direction = 1
            # elif self.y >= self.y2:
            #     self.direction = -1
        elif self.type == "Watcher":
            self.x += self.speed * self.direction
            if self.x <= self.x1:
                self.direction = 1
            elif self.x >= self.x2:
                self.direction = -1
            if random.randint(0, 750) == 1:
                return True
    

    def draw(self, screen):
        screen.blit(self.image, (self.x, self.y))
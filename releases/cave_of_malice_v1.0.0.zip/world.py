import pygame as pg
from enemy import Enemy
from coin import Coin
import os
import sys
import json
from save_path import get_save_path
# and use get_save_path() wherever data.json is opened

def resource_path(relative_path):
    base_path = None

    # PyInstaller (Windows/Linux builds)
    if hasattr(sys, "_MEIPASS"):
        base_path = sys._MEIPASS

    # macOS .app bundle
    elif getattr(sys, "frozen", False):
        base_path = os.path.dirname(sys.executable)
        base_path = os.path.abspath(os.path.join(base_path, "..", "Resources"))

    else:
        # dev mode
        base_path = os.path.abspath(".")

    return os.path.join(base_path, relative_path)


class World():
    def __init__(self, dirtImg, lavaImg, diamondImg, invisImg, TILE_SIZE):
        self.dirtImgS = dirtImg
        self.dirtImg = pg.transform.scale(pg.image.load(resource_path(dirtImg)), (TILE_SIZE, TILE_SIZE))
        self.lavaImgS = lavaImg
        self.lavaImg = pg.transform.scale(pg.image.load(resource_path(lavaImg)), (TILE_SIZE, TILE_SIZE))
        self.diamondImgS = diamondImg
        self.diamondImg = pg.transform.scale(pg.image.load(resource_path(diamondImg)), (TILE_SIZE, TILE_SIZE))
        self.invisImgS = invisImg
        self.invisImg = pg.transform.scale(pg.image.load(resource_path(invisImg)), (TILE_SIZE, TILE_SIZE))

        self.checkmark_img = pg.transform.scale(pg.image.load(resource_path("assets/checkmark.png")), (50, 50))
        self.dragging = False

        self.tileList = []
        self.TILE_SIZE = TILE_SIZE

        

    def load_map(self, mapName):
        try:
            with open(resource_path(mapName), "r") as file:
                level = [list(line.strip()) for line in file.readlines()]
                return level
        except FileNotFoundError:
            return 0
    

    def draw_map(self, SCREEN):
        # print(self.tileList)
        for tile in self.tileList:
            SCREEN.blit(tile[0], tile[1])
    
    def get_image(self, tile, source):
        if source:
            if tile == "1":
                return self.dirtImgS
            elif tile == "2":
                return self.lavaImgS
            elif tile == "3":
                return self.diamondImgS
            elif tile == "4":
                return self.invisImgS
        else:
            if tile == "1":
                return self.dirtImg
            elif tile == "2":
                return self.lavaImg
            elif tile == "3":
                return self.diamondImg
            elif tile == "4":
                return self.invisImg
            else:
                return self.dirtImg
    

    def load_tiles(self, level):
        self.tileList = []
        for row_index, row in enumerate(level):
            for col_index, tile in enumerate(row):
                if tile == "1" or tile == "2" or tile == "3" or tile == "4":
                    image = self.get_image(tile, False)
                    img = pg.transform.scale(image, (self.TILE_SIZE, self.TILE_SIZE))
                    imgRect = pg.Rect(col_index * self.TILE_SIZE, row_index * self.TILE_SIZE, self.TILE_SIZE, self.TILE_SIZE)
                    tile = (img, imgRect, self.get_image(tile, True))
                    self.tileList.append(tile)
    


    def display_text(self, x: int, y: int, text_string: str, font, color: tuple, SCREEN_X: int, SCREEN_Y: int, SCREEN, center=False):
        text_surface = font.render(text_string, True, color)
        text_width, text_height = text_surface.get_size()
        
        if x is None:
            x = (SCREEN_X / 2) - (text_width / 2)
        elif center == True:
            x = x - (text_width / 2)
        
        if y is None:
            y = (SCREEN_Y / 2) - (text_height / 2)


        SCREEN.blit(text_surface, (x, y))

        return text_surface.get_size()

    def spawn_assets(self, level, enemy_data, coin_data):
        enemies = []
        coins = []
        data = enemy_data["levels"][str(level)]
        for enemyd in data:
            enemy = Enemy(enemyd["type"], enemyd["init_x"], enemyd["init_y"], enemyd["width"], enemyd["height"], enemyd["speed"], enemyd["health"], enemyd["src_img"], enemyd["dir"], enemyd["num1"], enemyd["num2"], enemyd["power"])
            enemies.append(enemy)
            enemy = None
        
        data = coin_data["levels"][str(level)]
        for coind in data:
            coin = Coin(coind["type"], coind["x"], coind["y"], coind["width"], coind["height"], coind["src_img"])
            coins.append(coin)
            coin = None
        
        return enemies, coins

    def draw_button(self, x, y, width, height, color, text, SCREEN):
        pg.draw.rect(SCREEN, color, (x, y, width, height))
        text_rect = text.get_rect(center=(x + width // 2, y + height // 2))
        SCREEN.blit(text, text_rect)
    

    def draw_upgrade(self, name: str, x: int, y: int, x2: int, y2: int, text: str, font, color: tuple, SCREEN_X: int, SCREEN_Y: int, SCREEN, width: int, height: int, pic_path: str, x3: str, y3: str, upgrade_stage: str, mode=0):
        upgrade = pg.image.load(resource_path(pic_path))
        upgrade = pg.transform.scale(upgrade, (width, height))
        upgrade_rect = upgrade.get_rect(topleft=(x2, y2))

        text_surface = font.render(text, True, color)
        text_width, text_height = text_surface.get_size()

        if mode == 1:
            x = x - (text_width / 2)
        
        if x is None:
            x = (SCREEN_X / 2) - (text_width / 2)
        if y is None:
            y = (SCREEN_Y / 2) - (text_height / 2)

        SCREEN.blit(text_surface, (x, y))
        SCREEN.blit(upgrade, (x2, y2))

        if x3 != "" and y3 != "" and upgrade_stage != "":
            text_surface = font.render(upgrade_stage, True, color)
            text_width, text_height = text_surface.get_size()
            if mode == 1:
                x3 = int(x3) - (text_width / 2)
            SCREEN.blit(text_surface, (x3, int(y3)))

        return upgrade_rect, width, height, name
    
    def alert(self, SCREEN, string: str, font, corner=False):
        if corner:
            SCREEN.fill((100, 100, 100), ((SCREEN.get_width() // 2) + 350, 0, 290, 125))
            text_surface = font.render(string, True, (0, 0, 0))
            text_width, _ = text_surface.get_size()
            SCREEN.blit(text_surface, (SCREEN.get_width() // 2 - (text_width // 2) + 500, 20))

            button_text = pg.font.Font(None, 30).render("Close", True, (0, 0, 0))
            self.draw_button(SCREEN.get_width() // 2 + 530, 65, 80, 40, (255, 255, 255), button_text, SCREEN)

            button_text = pg.font.Font(None, 30).render("Download", True, (0, 0, 0))
            self.draw_button(SCREEN.get_width() // 2 + 390, 65, 110, 40, (255, 255, 255), button_text, SCREEN)
        else:
            SCREEN.fill((100, 100, 100), ((SCREEN.get_width() // 2) - 320, 0, 640, 150))
            text_surface = font.render(string, True, (0, 0, 0))
            text_width, _ = text_surface.get_size()
            SCREEN.blit(text_surface, (SCREEN.get_width() // 2 - (text_width // 2), 20))
            button_text = pg.font.Font(None, 36).render("Close", True, (0, 0, 0))
            self.draw_button(SCREEN.get_width() // 2 - 50, 75, 100, 50, (255, 255, 255), button_text, SCREEN)

    
    def reset_level(self, levels, player, currentLevel, action="new_level"):
        global level
        if action == "new_level":
            currentLevel += 1
            # player.health = 3
            level = levels[currentLevel]
            player.x = 90
            player.y = 608
            if hasattr(player, "hitbox"):
                player.hitbox.x = player.x
                player.hitbox.y = player.y
            player.coins += player.temp_coins
            player.temp_coins = 0
        elif action == "win_reset":
            currentLevel = 1
            level = levels[currentLevel]
        elif action == "die_reset":
            player.health -= 1
            player.x = 90
            player.y = 608
            if hasattr(player, "hitbox"):
                player.hitbox.x = player.x
                player.hitbox.y = player.y
            # player.coins += player.temp_coins

            player.temp_coins = 0
            level = levels[currentLevel]
        elif action == "full_reset":
            currentLevel = 1
            level = levels[currentLevel]
            player.x = 90
            player.y = 608
            if hasattr(player, "hitbox"):
                player.hitbox.x = player.x
                player.hitbox.y = player.y
            player.coins = 0
            player.temp_coins = 0
            player.health = player.max_health
        return level, currentLevel
    
    # def update_invisible_blocks(self, invis_list):
    #     blocks_to_remove = []
    #     blocks_to_add = []
    #     tiles_to_remove = []
        
    #     for i, block in enumerate(invis_list):
    #         image, rect, source, timer = block
            
    #         # Countdown timer
    #         timer -= 1
            
    #         if timer <= 0:
    #             # Determine next frame or removal
    #             if source == "assets/invis-frames/1.png":
    #                 next_frame = pg.image.load(resource_path("assets/invis-frames/2.png"))
    #                 next_frame = pg.transform.scale(next_frame, (32, 32))
    #                 next_source = "assets/invis-frames/2.png"
    #                 next_timer = 30
    #                 new_block = (next_frame, rect, next_source, next_timer)
    #                 blocks_to_add.append(new_block)
                    
    #             elif source == "assets/invis-frames/2.png":
    #                 next_frame = pg.image.load(resource_path("assets/invis-frames/3.png"))
    #                 next_frame = pg.transform.scale(next_frame, (32, 32))
    #                 next_source = "assets/invis-frames/3.png"
    #                 next_timer = 30
    #                 new_block = (next_frame, rect, next_source, next_timer)
    #                 blocks_to_add.append(new_block)
                    
    #             elif source == "assets/invis-frames/3.png":
    #                 # Block should disappear completely
    #                 # Find and mark corresponding tile for removal
    #                 for tile in self.tileList:
    #                     if len(tile) >= 2 and tile[1] == rect:
    #                         tiles_to_remove.append(tile)
    #                         break
                
    #             # Mark old block for removal
    #             blocks_to_remove.append(block)
    #         else:
    #             # Update timer for existing block
    #             updated_block = (image, rect, source, timer)
    #             blocks_to_add.append(updated_block)
    #             blocks_to_remove.append(block)
        
    #     # Apply all changes after iteration
    #     for block in blocks_to_remove:
    #         if block in invis_list:
    #             invis_list.remove(block)
        
    #     for block in blocks_to_add:
    #         invis_list.append(block)
        
    #     for tile in tiles_to_remove:
    #         if tile in self.tileList:
    #             self.tileList.remove(tile)

    def check_code(self, text_input: str, SCREEN, font, save_dir: str):
        alert = ""
        valid = False
        with open(os.path.join(save_dir, "data.json"), "r") as file:
            data = json.load(file)

        code = data["codes"].get(text_input)
        if code is None:
            alert = f"No match for code: {text_input}"
        else:
            if not code.get("used", False):
                alert = "Code matched. Reward: None"
                valid = True
            else:
                alert = "Code already used"

        return alert, valid
    
    def create_setting(self, y, SCREEN, SCREEN_X, SCREEN_Y, text_string, font, events, state, type="checkmark", slider_x=350):
        if type == "checkmark":
            if state == 0:
                rect = pg.rect.Rect(450, y, 50, 50)
                pg.draw.rect(SCREEN, (200, 200, 200), rect, 50, 10)
                self.display_text(650, y + 15, text_string, font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN)
            elif state == 1:
                SCREEN.blit(self.checkmark_img, (450, y))
                self.display_text(650, y + 15, text_string, font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN)
            for event in events:
                if event.type == pg.MOUSEBUTTONDOWN:
                    mouse_x, mouse_y = pg.mouse.get_pos()
                    if 450 <= mouse_x <= 500 and y <= mouse_y <= y + 50:
                        state = 1 - state
        elif type == "slider":
            padding = 20
            rect = pg.rect.Rect(200, y + 10, 300, 30)
            pg.draw.rect(SCREEN, (0, 0, 0), rect, 300)
            pg.draw.circle(SCREEN, (255, 255, 255), (slider_x, y + 25), 11)
            mouse_pos = pg.mouse.get_pos()
            for event in events:
                if event.type == pg.MOUSEBUTTONDOWN and rect.collidepoint(mouse_pos):
                    # slider_x = mouse_pos[0]
                    self.dragging = True
                elif event.type == pg.MOUSEBUTTONUP:
                    self.dragging = False
            
            if self.dragging:
                if rect.left + padding <= mouse_pos[0] <= rect.right - padding:
                    slider_x = mouse_pos[0]
                elif not rect.left + padding <= mouse_pos[0]:
                    slider_x = rect.left + padding
                elif not rect.right - padding >= mouse_pos[0]:
                    slider_x = rect.right - padding
            
            state = int(((slider_x - padding - rect.left) / (rect.width - 2 * padding)) * 100)
            # print(state)
            self.display_text(650, y + 15, f"{text_string}: {state}", font, (0, 0, 0), SCREEN_X, SCREEN_Y, SCREEN)

            return state, slider_x

        return state
import pygame as pg
import os
import sys
import random
import json
from paths import resource_path
# and use get_save_path() wherever data.json is opened

class Player():
    def __init__(self, x, y, width, height, speed, health, sourceImage, footY, gravity, jumpPower, sidePadding, max_health, luck, skins_owned, SAVE_DIR):
        self.save_dir = SAVE_DIR
        save_path = os.path.join(self.save_dir, "data.json") if self.save_dir else resource_path("data/data.json")
        with open(save_path, "r") as data_file:
            data = json.load(data_file)
        
        self.x = x
        self.y = y
        self.speed = speed
        self.health = health
        self.sourceImage = sourceImage
        self.xChange = 0
        self.yChange = 0
        self.gravity = gravity
        self.jumpPower = jumpPower
        self.luck = luck

        self.sidePadding = sidePadding
        self.jumps_available = 2

        self.coins = 0
        self.temp_coins = 0

        self.jumping = False
        self.on_ground = True

        self.freezeFrame = 0

        # Fixed hitbox dimensions — never change regardless of animation frame
        self.hitbox_width = width
        self.hitbox_height = height
        self.hitbox = pg.Rect(x, y, self.hitbox_width, self.hitbox_height)

        if y is None:
            self.y = footY - self.hitbox_height
            self.footY = footY
        elif footY is None:
            self.footY = self.y + self.hitbox_height

        self.skins = skins_owned

        # Load the visual image (size may differ from hitbox)
        self.image = pg.image.load(resource_path(self.sourceImage))
        img_w, img_h = self.image.get_size()
        max_w = width
        max_h = height
        scale_w = max_w / img_w
        scale_h = max_h / img_h
        scale = min(scale_w, scale_h)
        new_width = int(img_w * scale)
        new_height = int(img_h * scale)
        self.image = pg.transform.scale(self.image, (new_width, new_height))
        self.visual_width = new_width
        self.visual_height = new_height

        # Keep self.width/height as visual dimensions for draw offset
        self.width = new_width
        self.height = new_height

        # Mask is kept only for reference; collision uses hitbox
        self.mask = pg.mask.from_surface(self.image)

        self.max_health = max_health
        self.health_bar_width = 54
        self.health_bar_height = 10

        self.spinFrame = -100000
        self.spin = False
        self.rotationDegree = 0
        self.new_wheel = None
        self.dash_unlocked = False
        self.dashing = 0
        self.dash_direction = 0
        self.dashing_cooldown = 0


        self.state = "idle"
        self.state_frame = 0

        self.animation_sources = {}

        for skin in self.skins:
            if data["skins"][skin["name"]]["animation"]:
                self.animation_sources[skin["name"]] = {}

                for i in range(skin["animations"]["run_frames"]):
                    img = pg.image.load(resource_path(f"assets/{skin['name']}/r_run_{i}.png"))
                    img = pg.transform.scale(img, (
                        data["initial_params"]["initial_width"] * skin["animations"]["scale"],
                        data["initial_params"]["initial_height"] * skin["animations"]["scale"]
                    ))
                    self.animation_sources[skin["name"]][f"r_run_{i}"] = img

                    img = pg.image.load(resource_path(f"assets/{skin['name']}/l_run_{i}.png"))
                    img = pg.transform.scale(img, (
                        data["initial_params"]["initial_width"] * skin["animations"]["scale"],
                        data["initial_params"]["initial_height"] * skin["animations"]["scale"]
                    ))
                    self.animation_sources[skin["name"]][f"l_run_{i}"] = img

                for i in range(skin["animations"]["idle_frames"]):
                    img = pg.image.load(resource_path(f"assets/{skin['name']}/idle_{i}.png"))
                    img = pg.transform.scale(img, (
                        data["initial_params"]["initial_width"] * skin["animations"]["scale"],
                        data["initial_params"]["initial_height"] * skin["animations"]["scale"]
                    ))
                    self.animation_sources[skin["name"]][f"idle_{i}"] = img


    def default_ugrade_values(self):
        self.speed_upgrade_cost = 3
        self.speed_upgrade_level = 1
        self.speed_upgrade_stage = 1
        self.speed_stage_string = "Speed Level: " + str(self.speed_upgrade_stage)
        self.dash_upgrade_cost = 7
        self.dash_upgrade_level = 1
        self.dash_upgrade_stage = 1
        self.dash_stage_string = "Dash Level: " + str(self.dash_upgrade_stage)
        self.luck_upgrade_cost = 3
        self.luck_upgrade_level = 1
        self.luck_upgrade_stage = 1
        self.luck_upgrade_string = "Luck Level: " + str(self.luck_upgrade_stage)
        self.health_upgrade_cost = 3
        self.health_upgrade_level = 1
        self.health_upgrade_stage = 1
        self.health_upgrade_string = "Health Level: " + str(self.health_upgrade_stage)
        self.wheel_cost = 2
        self.wheel_level = 1
        self.wheel_spinning = False


    def check_walk(self):
        keys = pg.key.get_pressed()

        if (keys[pg.K_a] or keys[pg.K_LEFT]) and not (keys[pg.K_d] or keys[pg.K_RIGHT]):
            self.xChange = -self.speed
        elif (keys[pg.K_d] or keys[pg.K_RIGHT]) and not (keys[pg.K_a] or keys[pg.K_LEFT]):
            self.xChange = self.speed
        else:
            self.xChange = 0


    def move(self, tileList, invis_list, data, freeze=False):
        ifDead = False
        ifWin = False

        # 1. Read input first so everything below uses current frame's keys
        self.check_walk()

        if self.dash_unlocked: 
            if self.dashing > 0:
                if self.dash_direction == 1:
                    self.xChange = 20
                    self.yChange = 0
                else:
                    self.xChange = -20
                    self.yChange = 0
                self.dashing -= 1
                if self.dashing == 0:
                    self.dashing_cooldown = 90
                    self.dash_direction = 0
            elif self.dashing_cooldown > 0:
                self.dashing_cooldown -= 1


        # 3. Gravity
        if not self.on_ground:
            self.yChange += self.gravity

        self.on_ground = False

        # 2. Freeze overrides input
        if freeze or self.freezeFrame > 0:
            self.xChange = 0
            self.yChange = 0
            if freeze:
                self.freezeFrame = 60
            else:
                self.freezeFrame -= 1
                
        # 4. Move X, resolve X
        self.x += self.xChange
        self.hitbox.x = self.x

        for tile in tileList:
            if self.hitbox.colliderect(tile[1]):
                if tile[2] == "assets/lava.jpeg":
                    ifDead = True
                if tile[2] == "assets/diamond.png":
                    ifWin = True
                if self.xChange > 0:
                    self.hitbox.right = tile[1].left
                elif self.xChange < 0:
                    self.hitbox.left = tile[1].right
                self.x = self.hitbox.x
                self.xChange = 0

        # 5. Move Y, resolve Y
        self.y += self.yChange
        self.hitbox.y = self.y

        for tile in tileList:
            if self.hitbox.colliderect(tile[1]):
                if tile[2] == "assets/lava.jpeg":
                    ifDead = True
                if tile[2] == "assets/diamond.png":
                    ifWin = True
                if tile[2] == "assets/invis_block.png":
                    already_animating = any(
                        len(b) >= 2 and b[1] == tile[1] for b in invis_list
                    )
                    if not already_animating:
                        next_invis_frame = pg.image.load(resource_path("assets/invis-frames/1.png"))
                        next_invis_frame = pg.transform.scale(next_invis_frame, (32, 32))
                        animated_tile = (next_invis_frame, tile[1], "assets/invis-frames/1.png", 10)
                        invis_list.append(animated_tile)
                        for i, world_tile in enumerate(tileList):
                            if world_tile[1] == tile[1]:
                                tileList[i] = animated_tile
                                break
                if self.yChange > 0:
                    self.hitbox.bottom = tile[1].top
                    self.on_ground = True
                    self.jumps_available = 2
                elif self.yChange < 0:
                    self.hitbox.top = tile[1].bottom
                self.y = self.hitbox.y
                self.yChange = 0

        # 6. Animation — now xChange is correct for this frame
        if self.xChange > 0 and self.state != "r_run":
            self.state = "r_run"
            self.state_frame = 0
        elif self.xChange < 0 and self.state != "l_run":
            self.state = "l_run"
            self.state_frame = 0
        elif self.xChange == 0 and self.state in ("r_run", "l_run"):
            self.state = "idle"
            self.state_frame = 0

        if data["skins"][data["skin_selected"]]["animation"]:
            skin = data["skin_selected"]
            skin_data = data["skins"][skin]["animations"]

            run_frames  = skin_data["run_frames"]
            idle_frames = skin_data["idle_frames"]

            if self.state == "idle" and self.state_frame >= idle_frames:
                self.state_frame = 0
            elif self.state in ("r_run", "l_run") and self.state_frame >= run_frames:
                self.state_frame = 0

            self.sourceImage = f"assets/{skin}/{self.state}_{int(self.state_frame)}.png"
            self.image = pg.image.load(resource_path(self.sourceImage))
            img_w, img_h = self.image.get_size()
            new_width  = int(img_w * skin_data["scale"])
            new_height = int(img_h * skin_data["scale"])
            self.image = pg.transform.scale(self.image, (new_width, new_height))
            self.visual_width  = new_width
            self.visual_height = new_height
            self.width  = new_width
            self.height = new_height
            self.mask = pg.mask.from_surface(self.image)

            if skin == "pirate" and self.state in ("r_run", "l_run"):
                self.state_frame += 0.5
            else:
                self.state_frame += 0.2
            self.state_frame = round(self.state_frame, 1)

        # 7. Final hitbox sync
        self.hitbox.x = self.x
        self.hitbox.y = self.y

        return ifDead, ifWin


    def render_wheel(self):
        if self.spin or self.spinFrame >= -10:
            if self.spin:
                self.spinFrame = random.randint(30, 40)
                self.spin = False
            else:
                self.spinFrame -= 0.5


    def draw(self, screen):
        # Center the visual sprite over the hitbox horizontally,
        # and align the bottom of the sprite with the bottom of the hitbox
        draw_x = self.hitbox.x + (self.hitbox_width - self.visual_width) // 2
        draw_y = self.hitbox.y + (self.hitbox_height - self.visual_height)
        screen.blit(self.image, (draw_x, draw_y))

        # Debug: draw hitbox outline — remove this line when done testing
        # pg.draw.rect(screen, (255, 0, 0), self.hitbox, 1)


    def get_image_position(self):
        image_x = self.hitbox.x + (self.hitbox_width - self.visual_width) // 2
        image_y = self.hitbox.y + (self.hitbox_height - self.visual_height)
        return image_x, image_y


    def check_enemy_collision(self, enemies):
        image_x, image_y = self.get_image_position()
        for enemy in enemies:
            offset = (int(enemy.x - image_x), int(enemy.y - image_y))
            if self.mask.overlap(enemy.mask, offset):
                return True
        return False


    def check_coin_collision(self, coins):
        image_x, image_y = self.get_image_position()
        for coin in coins[:]:
            offset = (int(coin.x - image_x), int(coin.y - image_y))
            if self.mask.overlap(coin.mask, offset):
                self.temp_coins += 1
                coins.remove(coin)


    def upgrade(self, skil: str, skil_stage: int, health_frames_source=None, health_frames=None):
        if skil == "Speed":
            self.speed += 1
            skil_stage += 1
        elif skil == "Dash":
            self.dash_unlocked = True
            skil_stage += 1
        elif skil == "Luck":
            self.luck += 1
            skil_stage += 1
        elif skil == "Health":
            self.max_health += 1
            self.health += 1
            skil_stage += 1
            health_frames_source, health_frames = self.get_health_frames()
            return skil_stage, health_frames_source, health_frames
        else:
            return

        return skil_stage


    def change_player_skin(self, SCREEN_X: int, mouse_pos: tuple, skins_owned: list, skin_selected: int, mode="skin_selected"):
        legacy_index = None
        with open(os.path.join(self.save_dir, "data.json"), "r") as data_file:
            data = json.load(data_file)

        if mode == "legacy_index":
            for i in range(2):
                for j in range(6):
                    if i * 6 + j < len(skins_owned):
                        temp_skin_selected = i * 6 + j
                        name = skins_owned[temp_skin_selected]["name"]
                        if name == "default":
                            legacy_index = temp_skin_selected
            return legacy_index

        elif mode == "skin_selected":
            for i in range(2):
                for j in range(6):
                    if (
                        (SCREEN_X // 6) * j + SCREEN_X // 12 - 85 <= mouse_pos[0] <= (SCREEN_X // 6) * j + SCREEN_X // 12 - 85 + 170
                        and 140 + i * 210 <= mouse_pos[1] <= 140 + i * 210 + 170
                        and i * 6 + j < len(skins_owned)
                    ):
                        skin_selected = i * 6 + j
                        name = skins_owned[skin_selected]["name"]
                        data["skin_selected"] = name

                        with open(os.path.join(self.save_dir, "data.json"), "w") as data_file:
                            json.dump(data, data_file, indent=4)

                        self.sourceImage = f"assets/skins/{name}.png"
                        self.image = pg.image.load(resource_path(self.sourceImage))
                        img_w, img_h = self.image.get_size()
                        max_w = data["initial_params"]["initial_width"]
                        max_h = data["initial_params"]["initial_height"]
                        scale_w = max_w / img_w
                        scale_h = max_h / img_h
                        scale = min(scale_w, scale_h)
                        new_width = int(img_w * scale)
                        new_height = int(img_h * scale)
                        self.image = pg.transform.scale(self.image, (new_width, new_height))

                        # Visual dimensions update — hitbox stays the same
                        self.visual_width = new_width
                        self.visual_height = new_height
                        self.width = new_width
                        self.height = new_height

                        self.mask = pg.mask.from_surface(self.image)
            return skin_selected, data


    def get_health_frames(self):
        health_frames_source = []
        health_frames = []
        for i in range(self.max_health):
            health_frames_source.append(i + 1)

        try:
            for frame in health_frames_source:
                health_frame = pg.image.load(resource_path(f"assets/health-{str(self.max_health)}/health-{str(frame)}.png"))
                health_frame = pg.transform.scale(health_frame, (54, 10))
                touple = (health_frame, frame)
                health_frames.append(touple)
        except:
            pg.quit()
            sys.exit()

        return health_frames_source, health_frames


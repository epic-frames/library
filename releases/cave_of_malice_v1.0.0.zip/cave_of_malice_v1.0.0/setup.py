from setuptools import setup

APP = ["main.py"]

OPTIONS = {
    "argv_emulation": False,

    "packages": [
        "pygame",
        "requests"
    ],

    "resources": [
        "assets",
        "data",
        "credits.txt"
    ],

    "plist": {
        "CFBundleName": "Cave Of Malice",
        "CFBundleDisplayName": "Cave Of Malice",
        "CFBundleIdentifier": "com.epicframes.caveofmalice"
    }
}

setup(
    app=APP,
    options={"py2app": OPTIONS},
    setup_requires=["py2app"]
)
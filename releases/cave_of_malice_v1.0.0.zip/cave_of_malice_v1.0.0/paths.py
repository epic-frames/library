import os
import sys

APP_NAME = "Cave Of Malice"

def get_save_dir():
    if sys.platform == "darwin":
        base = os.path.expanduser("~/Library/Application Support/Cave Of Malice")
    elif sys.platform == "win32":
        base = os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")), "Cave Of Malice")
    else:
        base = os.path.expanduser("~/.cave_of_malice")
    os.makedirs(base, exist_ok=True)
    return base

def get_assets_dir():
    if sys.platform == "darwin":
        return os.path.expanduser("~/Library/Application Support/Cave Of Malice/game/assets")
    elif sys.platform == "win32":
        return os.path.join(os.environ.get("LOCALAPPDATA", os.path.expanduser("~")),
                             "Cave Of Malice", "game", "assets")
    else:
        return os.path.expanduser("~/.cave_of_malice/game/assets")

def get_game_dir():
    if sys.platform == "darwin":
        return os.path.join(
            os.path.expanduser("~/Library/Application Support"),
            APP_NAME,
            "game"
        )

    elif sys.platform.startswith("win"):
        return os.path.join(
            os.environ.get("LOCALAPPDATA",
                           os.path.expanduser("~")),
            APP_NAME,
            "game"
        )

    else:
        return os.path.join(
            os.path.expanduser("~/.local/share"),
            APP_NAME,
            "game"
        )

GAME_DIR = get_game_dir()

def resource_path(path):
    return os.path.join(GAME_DIR, path)